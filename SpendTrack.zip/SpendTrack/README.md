# SpendTrack

A private Android app that reads the payment alerts your bank sends by SMS
(every Google Pay / UPI payment triggers one) and shows how much of your
monthly budget is left.

## What it does

- Finds debit messages from your bank for the month and adds them up.
- You set a monthly budget; it shows what's left and a safe amount per day.
- "Can I buy this?": type a price and see whether it fits in what's left.
- Groups spending into categories (Food, Groceries, Transport, ...). Tap any
  transaction to change its category or to stop counting it (for example a
  transfer to your own account).
- UPI Lite top-ups count as spending, because payments made from UPI Lite
  don't send a bank SMS of their own.
- **Import statement** (next to the Transactions heading) reads a bank
  statement saved as .xlsx or CSV and adds the payments that never sent an
  SMS. Lines already known from SMS are matched by UPI reference number and
  not counted twice.
- Filter chips above the list show entries by source: SMS only, statement
  only, found in both, or added by you.
- Password protected: the first launch makes you create a password, and the
  app asks for it every time it is opened. It can be changed (top right of the
  home screen) but not switched off. The app is also hidden from screenshots
  and the recent-apps preview. A forgotten password can't be recovered:
  clearing the app's data in phone Settings is the only reset.
- Tap a transaction to add your own remarks; they show under it in the list.
- The + button adds cash expenses that never produced an SMS.
- Shows the bank balance from the latest SMS that mentions one.
- Previous months are available with the arrows at the top.

## Privacy

The app asks for one permission: reading SMS. It has no internet permission,
so nothing it reads can leave the phone. Budget, categories and cash entries
are stored in the app's private storage.

## Getting the APK

This project has not been compiled yet. Pick one way to build it:

### A. GitHub builds it for you (no computer needed once the code is there)

1. Create a new repository on github.com and put this whole folder in it,
   including the hidden `.github` folder.
2. Open the repository's **Actions** tab. A run called "Build APK" starts on
   its own and takes about five minutes.
3. Open **Releases** on the repository page and download `SpendTrack.apk`.

### B. Android Studio on a computer

1. Open this folder in Android Studio and let it finish syncing.
2. Build > Build App Bundle(s) / APK(s) > Build APK(s).

## Installing on the phone

1. Open `SpendTrack.apk` and allow installing from that source when asked.
2. Open the app and tap **Allow SMS access**.
3. If Android refuses the permission (newer versions restrict SMS access for
   apps installed outside the Play Store): Settings > Apps > SpendTrack, tap the
   three dots at the top right, choose **Allow restricted settings**, then
   Permissions > SMS > Allow.

## Good to know

- It can only see payments your bank texted you about. If a payment shows the
  wrong shop name or is missed, the SMS wording is one the reader doesn't know
  yet; `SmsParser.kt` is the file to adjust.
- The signing key in `app/spendtrack.keystore` is included on purpose so each
  new build installs over the old one. It is fine for a personal app; don't use
  it for anything you publish.
