plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.spendtrack.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.spendtrack.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 15
        versionName = "2.4"
    }

    // One fixed signing key kept in the project, so every build can be
    // installed over the previous one without uninstalling first.
    signingConfigs {
        create("shared") {
            storeFile = file("spendtrack.keystore")
            storePassword = "spendtrack"
            keyAlias = "spendtrack"
            keyPassword = "spendtrack"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    // Reads the text of Google Pay PDF statements.
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    // Daily check for the statement reminder.
    implementation("androidx.work:work-runtime-ktx:2.9.0")
}
