package com.spendtrack.app

/** Result of reading one bank / UPI message. */
data class ParsedSms(
    val amount: Double,
    val merchant: String,
    val isDebit: Boolean,
    val balance: Double?,
    val category: String,
    val ref: String? = null
)

/**
 * Turns Indian bank / UPI transaction SMS into structured data.
 * Pure Kotlin (no Android classes) so it can be tested on its own.
 */
object SmsParser {

    val CATEGORIES = listOf(
        "Food", "Groceries", "Transport", "Shopping", "Bills",
        "Entertainment", "Health", "Cash", "UPI Lite", "Transfer", "Other"
    )

    private val I = RegexOption.IGNORE_CASE
    private const val NUM = "([0-9][0-9,]*(?:\\.[0-9]{1,2})?)"
    private const val CUR = "(?:\\brs[.:]?|\\binr[.:]?|₹)"

    private val debitWord = Regex("\\b(debited|sent|spent|paid|withdrawn|purchase|deducted)\\b", I)
    private val creditWord = Regex("\\b(credited|received|deposited|refund|refunded)\\b", I)

    // Messages that mention money but are not completed transactions.
    private val notATransaction = Regex(
        "\\botp\\b|one time password|will be debited|would be debited|to be debited|" +
            "will be deducted|\\bdue\\b|failed|declined|unsuccessful|not completed|" +
            "has requested|collect request|payment request|requested money|" +
            "pre-approved|preapproved|\\boffer\\b|cashback up to|\\bwin\\b",
        I
    )

    private val upiLiteTopUp = Regex("upi\\s*lite.*(top-?\\s?up|load|added)|(top-?\\s?up|load|added).*upi\\s*lite", I)

    private val amountNearVerb = Regex(
        "(?:debited|sent|spent|paid|withdrawn|deducted|credited|received|deposited|purchase)" +
            "\\s+(?:by|for|of|with)?\\s*$CUR?\\s*$NUM",
        I
    )
    private val amountWithCurrency = Regex("$CUR\\s*$NUM", I)
    private val balanceRx = Regex(
        "(?:avl\\.?\\s?bal(?:ance)?|available\\s+bal(?:ance)?|\\bbal(?:ance)?)" +
            "\\s*(?:is|:|-)?\\s*$CUR?\\s*$NUM",
        I
    )

    private const val END = "(?:\\s+on\\b|\\s+from\\b|\\s+ref|\\s+upi|\\s+via\\b|\\s+not you|\\s+if not|\\s*[.,;(]\\s|[.,;]?\$)"
    private val mAxis = Regex("UPI/P2[MA]/[0-9]+/(.+?)(?:/|\\s+not you|\$)", I)
    private val mIcici = Regex(";\\s*(.+?)\\s+credited", I)
    private val mVpa = Regex("(?:to|at)\\s+vpa\\s+(\\S+)", I)
    private val mTrf = Regex("trf to\\s+(.+?)(?:\\s+ref|[.,;]\\s|[.,;]?\$)", I)
    private val mAt = Regex("\\bat\\s+(.+?)$END", I)
    private val mTo = Regex("\\bto\\s+(.+?)$END", I)
    private val mFrom = Regex("\\b(?:from|by)\\s+(.+?)$END", I)
    private val cardSpend = Regex("\\b(spent|purchase)\\b", I)

    fun parse(sender: String, body: String): ParsedSms? {
        // Bank alerts come from named senders (e.g. "VM-HDFCBK"), not phone numbers.
        if (sender.none { it.isLetter() }) return null

        val text = body.replace(Regex("\\s+"), " ").trim()
        if (notATransaction.containsMatchIn(text)) return null

        // UPI Lite: small Lite payments send no bank SMS, so the top-up itself
        // is the only record of that money being spent. Count it as spending.
        if (upiLiteTopUp.containsMatchIn(text)) {
            val amt = amountWithCurrency.find(text)?.groupValues?.get(1)?.let { toNumber(it) }
            if (amt != null && amt > 0.0) {
                return ParsedSms(amt, "UPI Lite top-up", true, null, "UPI Lite", findRef(text))
            }
        }

        val isDebit = debitWord.containsMatchIn(text)
        val isCredit = creditWord.containsMatchIn(text)
        if (!isDebit && !isCredit) return null
        // Money in must be money into a bank account. Shops and billers also say
        // "we have received your payment", and wallets announce cashback; those
        // are not income.
        if (!isDebit && !isAccountCredit(text)) return null

        val amountText = amountNearVerb.find(text)?.groupValues?.get(1)
            ?: amountWithCurrency.find(text)?.groupValues?.get(1)
            ?: return null
        val amount = toNumber(amountText) ?: return null
        if (amount <= 0.0) return null

        val balance = balanceRx.find(text)?.groupValues?.get(1)?.let { toNumber(it) }
        val merchant = if (isDebit) debitMerchant(text) else creditSource(text)
        val category = if (isDebit) guessCategory(merchant, text) else "Other"
        return ParsedSms(amount, merchant, isDebit, balance, category, findRef(text))
    }

    private val refAfterWord = Regex(
        "(?:ref(?:erence)?\\.?\\s*(?:no|number|id)?|refno|rrn|upi|txn\\s*id)[\\s:.#/-]*(?:P2[MA]/)?([0-9]{9,16})", I
    )
    private val twelveDigits = Regex("(?<![0-9])[0-9]{12}(?![0-9])")

    /** The UPI reference number, used to match an SMS with a bank statement line. */
    fun findRef(text: String): String? =
        refAfterWord.find(text)?.groupValues?.get(1) ?: twelveDigits.find(text)?.value

    private val accountWord = Regex("\\b(a/c|a/c\\.|ac|acct|account)\\b|\\ba/c[ xX*]*[0-9]", I)
    private val notIncome = Regex(
        "will be credited|would be credited|to be credited|received your payment|" +
            "payment (of [^.]*)?received|thank you for (your )?payment|credit card|card ending|" +
            "cashback|reward|wallet|loyalty|points|coins|voucher|e-?mandate|autopay",
        I
    )

    /** True for "your bank account was credited" messages, not merchant receipts. */
    fun isAccountCredit(text: String): Boolean =
        accountWord.containsMatchIn(text) && !notIncome.containsMatchIn(text)

    private fun toNumber(s: String): Double? = s.replace(",", "").toDoubleOrNull()

    private fun debitMerchant(text: String): String {
        val ordered = if (cardSpend.containsMatchIn(text))
            listOf(mAxis, mIcici, mVpa, mTrf, mAt, mTo)
        else
            listOf(mAxis, mIcici, mVpa, mTrf, mTo, mAt)
        for (rx in ordered) {
            val name = clean(rx.find(text)?.groupValues?.get(1))
            if (name != null) return name
        }
        return "Unknown"
    }

    private fun creditSource(text: String): String =
        clean(mFrom.find(text)?.groupValues?.get(1)) ?: "Money received"

    private fun clean(raw: String?): String? {
        if (raw == null) return null
        var s = raw.trim().trim('.', ',', ';', ':', '-', ' ')
        if (s.contains('@')) s = s.substringBefore('@')
        if (s.length < 2) return null
        val low = s.lowercase()
        if (low.startsWith("your") || low.startsWith("a/c") || low.startsWith("ac ") ||
            low.startsWith("acct") || low.startsWith("account") || low.startsWith("card") ||
            low.contains(" a/c ") || low.contains("bank a/c")
        ) return null
        if (s.length > 30) s = s.substring(0, 30).trim()
        return s
    }

    private val keywords: List<Pair<String, List<String>>> = listOf(
        "Cash" to listOf("withdrawn", "atm"),
        "Food" to listOf("swiggy", "zomato", "restaurant", "cafe", "domino", "pizza", "kfc",
            "mcdonald", "burger", "biryani", "bakery", "sweets", "dhaba", "food", "tea", "chai",
            "hotel", "farshan", "bites", "bundl", "snacks", "juice"),
        "Groceries" to listOf("bigbasket", "blinkit", "zepto", "dmart", "grofers", "instamart",
            "kirana", "grocery", "supermarket", "provision", "reliance fresh", "more retail",
            "dairy", "milk", "vegetable"),
        "Transport" to listOf("uber", "ola", "rapido", "irctc", "metro", "petrol", "fuel", "hpcl",
            "bpcl", "iocl", "indian oil", "fastag", "redbus", "railway", "parking", "namma yatri",
            "highways", "gas station", "service station", "toll"),
        "Shopping" to listOf("amazon", "flipkart", "myntra", "ajio", "meesho", "nykaa",
            "croma", "decathlon", "lifestyle", "trends"),
        "Bills" to listOf("electricity", "recharge", "airtel", "jio", "bsnl", "vodafone",
            "broadband", "dth", "bill", "bescom", "water board", "insurance", "lic ", "rent"),
        "Entertainment" to listOf("netflix", "hotstar", "spotify", "bookmyshow", "pvr", "inox",
            "youtube", "sony liv", "zee5", "game"),
        "Health" to listOf("pharmacy", "medical", "apollo", "hospital", "1mg", "pharmeasy",
            "clinic", "diagnostic", "chemist", "netmeds")
    )

    fun guessCategory(merchant: String, text: String): String {
        val m = merchant.lowercase()
        for ((cat, words) in keywords) {
            if (cat == "Cash") continue
            if (words.any { m.contains(it) }) return cat
        }
        val t = text.lowercase()
        if (t.contains("withdrawn") || Regex("\\batm\\b").containsMatchIn(t)) return "Cash"
        return "Other"
    }
}
