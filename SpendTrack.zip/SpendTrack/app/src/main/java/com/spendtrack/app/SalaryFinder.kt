package com.spendtrack.app

import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

/** A credit (money in) that might be the salary. */
data class Credit(
    val id: String,
    val time: Long,
    val amount: Double,
    val details: String,
    val fromStatement: Boolean
)

/** What the user has taught the finder, plus the last salary it found. */
data class SalaryHints(
    /** Credits the user marked "This is my salary". */
    val yes: Set<String> = emptySet(),
    /** Credits the user marked "Not my salary". */
    val no: Set<String> = emptySet(),
    /** Words from confirmed salary credits, such as the employer's code. */
    val tokens: Set<String> = emptySet(),
    /** The most recent salary amount, for spotting next month's. */
    val lastAmount: Double? = null
)

/**
 * Finds the monthly salary credit.
 *
 * The salary for a month M arrives at the end of the month before: on its last
 * day if that's a bank working day, otherwise on the last working day before.
 * Weekends, bank holidays and 2nd/4th Saturdays can pull it a few days earlier,
 * and once in a while it slips into the first days of M. So for month M the
 * finder looks from 7 days before the end of the previous month up to the 5th
 * of M, rather than trying to know every bank holiday.
 *
 * Inside that window a credit has to be at least ₹60,000 and look like a salary:
 * a "CEMTEX DEP" bulk credit (how SBI shows payroll credits), or words learned
 * from a salary the user confirmed, or an amount within 15% of the last salary.
 * Each candidate is scored and the best one wins. The user can always override
 * with "This is my salary" / "Not my salary", which the finder learns from.
 */
object SalaryFinder {
    const val MIN_AMOUNT = 60_000.0

    private val generic = setOf("CEMTEX", "TRANSFER", "DEPOSIT", "CREDIT", "BRANCH", "NEFT", "IMPS", "SALARY")

    /** The month a credit on this date would be salary for. */
    fun payMonthOf(date: LocalDate): YearMonth =
        if (date.dayOfMonth >= 20) YearMonth.from(date).plusMonths(1) else YearMonth.from(date)

    /** First and last day to look for month M's salary. */
    fun window(payMonth: YearMonth): Pair<LocalDate, LocalDate> =
        payMonth.minusMonths(1).atEndOfMonth().minusDays(7) to payMonth.atDay(5)

    fun isCemtex(details: String): Boolean = details.contains("CEMTEX", ignoreCase = true)

    /** Distinctive words of a narration, leaving out long reference numbers. */
    fun tokens(details: String): Set<String> =
        details.uppercase().split(Regex("[^A-Z0-9]+"))
            .filter { it.length >= 4 && !Regex("[0-9]{5,}").containsMatchIn(it) && it !in generic }
            .toSet()

    fun find(credits: List<Credit>, payMonth: YearMonth, hints: SalaryHints, zone: ZoneId): Credit? {
        val (from, to) = window(payMonth)
        val inWindow = credits.filter {
            val d = Instant.ofEpochMilli(it.time).atZone(zone).toLocalDate()
            !d.isBefore(from) && !d.isAfter(to)
        }
        // The user's own choice always wins.
        inWindow.filter { it.id in hints.yes }.maxByOrNull { it.amount }?.let { return it }

        val last = hints.lastAmount
        val endOfPrev = payMonth.minusMonths(1).atEndOfMonth()
        var best: Credit? = null
        var bestScore = Int.MIN_VALUE
        for (c in inWindow) {
            if (c.id in hints.no || c.amount < MIN_AMOUNT) continue
            val cemtex = isCemtex(c.details)
            val learned = hints.tokens.isNotEmpty() && tokens(c.details).any { it in hints.tokens }
            val close = last != null && Math.abs(c.amount - last) <= last * 0.15
            if (!cemtex && !learned && !close) continue
            val day = Instant.ofEpochMilli(c.time).atZone(zone).toLocalDate()
            var score = 0
            if (cemtex) score += 3
            if (learned) score += 2
            if (close) score += 2
            if (c.fromStatement) score += 1
            if (!day.isBefore(endOfPrev.minusDays(3)) && !day.isAfter(endOfPrev)) score += 1
            if (score > bestScore || (score == bestScore && c.amount > (best?.amount ?: 0.0))) {
                best = c
                bestScore = score
            }
        }
        return best
    }
}
