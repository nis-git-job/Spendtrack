package com.spendtrack.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Runs about once a day and reminds the user when a statement import is due. */
class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        try {
            Reminders.checkAndNotify(applicationContext)
        } catch (e: Exception) {
            // A reminder is never worth crashing over.
        }
        return Result.success()
    }
}

object Reminders {
    const val EVERY_DAYS = 7
    private const val DAY = 24L * 60 * 60 * 1000
    private const val WORK = "statement_reminder"
    private const val CHANNEL = "reminders"

    /** Starts or stops the daily check to match the setting. */
    fun schedule(context: Context) {
        val wm = WorkManager.getInstance(context.applicationContext)
        if (Store(context).remindersOn) {
            wm.enqueueUniquePeriodicWork(
                WORK,
                ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS).build()
            )
        } else {
            wm.cancelUniqueWork(WORK)
        }
    }

    /** Whole days since the last statement import, or null if there has never been one. */
    fun daysSinceImport(store: Store): Int? {
        val last = store.lastImportTime
        if (last <= 0L) return null
        return ((System.currentTimeMillis() - last) / DAY).toInt()
    }

    /** True when 7 days have passed since the last import (or since reminders started). */
    fun isDue(store: Store): Boolean {
        if (!store.remindersOn) return false
        val base = maxOf(store.lastImportTime, store.reminderSince)
        return base > 0L && System.currentTimeMillis() - base >= EVERY_DAYS * DAY
    }

    fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    fun checkAndNotify(context: Context) {
        val store = Store(context)
        if (!isDue(store)) return
        if (System.currentTimeMillis() - store.lastReminded < 20 * 60 * 60 * 1000L) return
        if (!canNotify(context)) return

        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Statement reminders", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val open = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val days = daysSinceImport(store)
        // Keep the text free of money details: it can show on the lock screen.
        val text = if (days == null) "Import your bank statement to keep SpendTrack complete."
        else "It's been $days days since your last statement import."
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Time to import your statement")
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(1001, n)
            store.lastReminded = System.currentTimeMillis()
        } catch (e: SecurityException) {
            // Notifications were turned off for the app.
        }
    }
}
