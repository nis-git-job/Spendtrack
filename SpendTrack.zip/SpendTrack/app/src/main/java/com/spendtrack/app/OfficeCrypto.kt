package com.spendtrack.app

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/** The file is locked and no password (or the wrong one) was given. */
open class StatementPasswordException(message: String) : StatementException(message)
class StatementPasswordNeeded : StatementPasswordException("This file is password-protected. Enter its password to open it.")
class StatementWrongPassword : StatementPasswordException("That password didn't open the file. Try again.")

/**
 * Reads the "compound file" container that old Excel files and
 * password-protected Excel files are stored in. Only reading is supported.
 */
class CompoundFile(private val data: ByteArray) {
    private val sectorSize: Int
    private val miniSectorSize: Int
    private val miniCutoff: Long
    private val fat: IntArray
    private val miniFat: IntArray
    private val entries = ArrayList<Entry>()
    private val miniStream: ByteArray

    class Entry(val name: String, val type: Int, val start: Int, val size: Long)

    init {
        if (data.size < 512 || !isCompound(data)) throw StatementException("Not a compound file.")
        sectorSize = 1 shl u16(0x1E)
        miniSectorSize = 1 shl u16(0x20)
        if (sectorSize != 512 && sectorSize != 4096) throw StatementException("Unsupported file layout.")
        miniCutoff = u32(0x38)

        // Sectors holding the FAT: 109 listed in the header, the rest in DIFAT sectors.
        val fatSectors = ArrayList<Int>()
        for (i in 0 until 109) {
            val s = i32(0x4C + i * 4)
            if (s >= 0) fatSectors.add(s)
        }
        var difat = i32(0x44)
        var guard = 0
        val perSector = sectorSize / 4
        while (difat >= 0 && guard++ < 100_000) {
            val off = offset(difat)
            for (i in 0 until perSector - 1) {
                val s = i32(off + i * 4)
                if (s >= 0) fatSectors.add(s)
            }
            difat = i32(off + (perSector - 1) * 4)
        }
        fat = IntArray(fatSectors.size * perSector)
        for ((n, s) in fatSectors.withIndex()) {
            val off = offset(s)
            for (i in 0 until perSector) fat[n * perSector + i] = i32(off + i * 4)
        }

        val dir = readChain(i32(0x30), -1)
        for (i in 0 until dir.size / 128) {
            val b = i * 128
            val nameLen = (dir[b + 64].toInt() and 0xFF) or ((dir[b + 65].toInt() and 0xFF) shl 8)
            val type = dir[b + 66].toInt() and 0xFF
            if (type == 0) continue
            val chars = ((nameLen - 2).coerceIn(0, 64)) / 2
            val name = String(dir, b, chars * 2, Charsets.UTF_16LE)
            val start = le32(dir, b + 116)
            val size = le32(dir, b + 120).toLong() and 0xFFFFFFFFL
            entries.add(Entry(name, type, start, size))
        }
        val root = entries.firstOrNull { it.type == 5 } ?: throw StatementException("Damaged file.")
        miniStream = if (root.size > 0) readChain(root.start, root.size) else ByteArray(0)
        val mf = if (i32(0x3C) >= 0) readChain(i32(0x3C), -1) else ByteArray(0)
        miniFat = IntArray(mf.size / 4) { le32(mf, it * 4) }
    }

    fun has(name: String): Boolean = entries.any { it.type == 2 && it.name.equals(name, ignoreCase = true) }

    fun stream(name: String): ByteArray {
        val e = entries.firstOrNull { it.type == 2 && it.name.equals(name, ignoreCase = true) }
            ?: throw StatementException("Missing part: $name")
        return if (e.size < miniCutoff) readMini(e.start, e.size) else readChain(e.start, e.size)
    }

    private fun readChain(start: Int, size: Long): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        var s = start
        var guard = 0
        while (s >= 0 && guard++ < 2_000_000) {
            val off = offset(s)
            if (off + sectorSize > data.size) break
            out.write(data, off, sectorSize)
            if (size >= 0 && out.size() >= size) break
            s = if (s < fat.size) fat[s] else -2
        }
        val all = out.toByteArray()
        return if (size in 0..all.size.toLong()) all.copyOf(size.toInt()) else all
    }

    private fun readMini(start: Int, size: Long): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        var s = start
        var guard = 0
        while (s >= 0 && guard++ < 2_000_000) {
            val off = s * miniSectorSize
            if (off + miniSectorSize > miniStream.size) break
            out.write(miniStream, off, miniSectorSize)
            if (out.size() >= size) break
            s = if (s < miniFat.size) miniFat[s] else -2
        }
        return out.toByteArray().copyOf(size.toInt())
    }

    private fun offset(sector: Int): Int = (sector + 1) * sectorSize
    private fun u16(at: Int): Int = (data[at].toInt() and 0xFF) or ((data[at + 1].toInt() and 0xFF) shl 8)
    private fun i32(at: Int): Int = le32(data, at)
    private fun u32(at: Int): Long = le32(data, at).toLong() and 0xFFFFFFFFL

    companion object {
        private val MAGIC = byteArrayOf(
            0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte(), 0xA1.toByte(), 0xB1.toByte(), 0x1A, 0xE1.toByte()
        )

        fun isCompound(b: ByteArray): Boolean = b.size >= 8 && (0 until 8).all { b[it] == MAGIC[it] }

        fun le32(b: ByteArray, at: Int): Int =
            (b[at].toInt() and 0xFF) or ((b[at + 1].toInt() and 0xFF) shl 8) or
                ((b[at + 2].toInt() and 0xFF) shl 16) or ((b[at + 3].toInt() and 0xFF) shl 24)
    }
}

/**
 * Unlocks password-protected Excel (.xlsx) files: both ways Excel encrypts
 * them, "agile" (Excel 2010 and later) and "standard" (Excel 2007).
 */
object OfficeCrypto {

    fun isEncrypted(cf: CompoundFile): Boolean = cf.has("EncryptionInfo") && cf.has("EncryptedPackage")

    /** Returns the unlocked .xlsx bytes, or throws StatementWrongPassword. */
    fun decrypt(cf: CompoundFile, password: String): ByteArray {
        val info = cf.stream("EncryptionInfo")
        val pkg = cf.stream("EncryptedPackage")
        val major = (info[0].toInt() and 0xFF) or ((info[1].toInt() and 0xFF) shl 8)
        val minor = (info[2].toInt() and 0xFF) or ((info[3].toInt() and 0xFF) shl 8)
        return when {
            major == 4 && minor == 4 -> agile(info, pkg, password)
            (major == 3 || major == 4) && minor == 2 -> standard(info, pkg, password)
            else -> throw StatementException(
                "This file uses a kind of password protection the app can't open. Open it in " +
                    "Excel or Google Sheets, enter the password, and save a copy without one."
            )
        }
    }

    // ----- agile -----

    private val BLOCK_VERIFIER_INPUT = hex("fea7d2763b4b9e79")
    private val BLOCK_VERIFIER_VALUE = hex("d7aa0f6d3061344e")
    private val BLOCK_KEY_VALUE = hex("146e0be7abacd0d6")

    private fun agile(info: ByteArray, pkg: ByteArray, password: String): ByteArray {
        val xml = String(info, 8, info.size - 8, Charsets.UTF_8)
        val keyData = attrs(xml, "keyData")
        val key = attrs(xml, "encryptedKey")
        if (keyData.isEmpty() || key.isEmpty()) throw StatementException("Couldn't read the file's protection details.")
        if (!(key["cipherAlgorithm"] ?: "AES").equals("AES", ignoreCase = true) ||
            !(keyData["cipherAlgorithm"] ?: "AES").equals("AES", ignoreCase = true)
        ) throw StatementException("This file uses an encryption method the app can't open.")

        val hashName = digestName(key["hashAlgorithm"] ?: "SHA512")
        val spin = (key["spinCount"] ?: "100000").toInt()
        val salt = b64(key["saltValue"])
        val keyBytes = (key["keyBits"] ?: "256").toInt() / 8
        val blockSize = (key["blockSize"] ?: "16").toInt()

        var h = digest(hashName, salt, password.toByteArray(Charsets.UTF_16LE))
        val counter = ByteArray(4)
        for (i in 0 until spin) {
            ByteBuffer.wrap(counter).order(ByteOrder.LITTLE_ENDIAN).putInt(i)
            h = digest(hashName, counter, h)
        }
        fun derived(block: ByteArray) = fit(digest(hashName, h, block), keyBytes)
        val iv = fit(salt, blockSize)

        val verifierInput = cbc(derived(BLOCK_VERIFIER_INPUT), iv, b64(key["encryptedVerifierHashInput"]))
            .copyOf(salt.size)
        val verifierHash = cbc(derived(BLOCK_VERIFIER_VALUE), iv, b64(key["encryptedVerifierHashValue"]))
        val expected = digest(hashName, verifierInput)
        if (!MessageDigest.isEqual(expected, verifierHash.copyOf(expected.size))) throw StatementWrongPassword()

        val secret = cbc(derived(BLOCK_KEY_VALUE), iv, b64(key["encryptedKeyValue"]))
            .copyOf((keyData["keyBits"] ?: "256").toInt() / 8)

        val dataHash = digestName(keyData["hashAlgorithm"] ?: "SHA512")
        val dataSalt = b64(keyData["saltValue"])
        val dataBlock = (keyData["blockSize"] ?: "16").toInt()
        val total = ByteBuffer.wrap(pkg, 0, 8).order(ByteOrder.LITTLE_ENDIAN).long
        if (total < 0 || total > 200_000_000) throw StatementException("Damaged file.")
        val out = java.io.ByteArrayOutputStream(total.toInt())
        var pos = 8
        var segment = 0
        val idx = ByteArray(4)
        while (pos < pkg.size && out.size() < total) {
            val len = minOf(4096, pkg.size - pos)
            val chunk = pkg.copyOfRange(pos, pos + len - (len % dataBlock))
            ByteBuffer.wrap(idx).order(ByteOrder.LITTLE_ENDIAN).putInt(segment)
            val segIv = fit(digest(dataHash, dataSalt, idx), dataBlock)
            out.write(cbc(secret, segIv, chunk))
            pos += len
            segment++
        }
        return out.toByteArray().copyOf(total.toInt())
    }

    // ----- standard -----

    private fun standard(info: ByteArray, pkg: ByteArray, password: String): ByteArray {
        val buf = ByteBuffer.wrap(info).order(ByteOrder.LITTLE_ENDIAN)
        buf.position(8)
        val headerSize = buf.int
        val headerStart = buf.position()
        buf.int // flags
        buf.int // size extra
        val algId = buf.int
        buf.int // hash algorithm (SHA-1)
        val keyBits = buf.int
        if (algId and 0xFF00 != 0x6600) throw StatementException("This file uses an encryption method the app can't open.")
        buf.position(headerStart + headerSize)
        val saltSize = buf.int
        val salt = ByteArray(saltSize).also { buf.get(it) }
        val encVerifier = ByteArray(16).also { buf.get(it) }
        val verifierHashSize = buf.int
        val encVerifierHash = ByteArray(32).also { buf.get(it) }

        var h = digest("SHA-1", salt, password.toByteArray(Charsets.UTF_16LE))
        val counter = ByteArray(4)
        for (i in 0 until 50_000) {
            ByteBuffer.wrap(counter).order(ByteOrder.LITTLE_ENDIAN).putInt(i)
            h = digest("SHA-1", counter, h)
        }
        val hFinal = digest("SHA-1", h, ByteArray(4))
        val b1 = ByteArray(64) { 0x36 }
        val b2 = ByteArray(64) { 0x5C }
        for (i in hFinal.indices) {
            b1[i] = (b1[i].toInt() xor hFinal[i].toInt()).toByte()
            b2[i] = (b2[i].toInt() xor hFinal[i].toInt()).toByte()
        }
        val key = (digest("SHA-1", b1) + digest("SHA-1", b2)).copyOf(keyBits / 8)

        val verifier = ecb(key, encVerifier)
        val verifierHash = ecb(key, encVerifierHash).copyOf(verifierHashSize)
        if (!MessageDigest.isEqual(digest("SHA-1", verifier), verifierHash)) throw StatementWrongPassword()

        val total = ByteBuffer.wrap(pkg, 0, 8).order(ByteOrder.LITTLE_ENDIAN).long
        if (total < 0 || total > 200_000_000) throw StatementException("Damaged file.")
        val body = pkg.copyOfRange(8, pkg.size)
        val usable = body.copyOf(body.size - body.size % 16)
        return ecb(key, usable).copyOf(total.toInt())
    }

    // ----- helpers -----

    private fun attrs(xml: String, element: String): Map<String, String> {
        val m = Regex("<(?:[A-Za-z0-9]+:)?$element\\b([^>]*)>").find(xml) ?: return emptyMap()
        val out = HashMap<String, String>()
        for (a in Regex("([A-Za-z]+)=\"([^\"]*)\"").findAll(m.groupValues[1])) out[a.groupValues[1]] = a.groupValues[2]
        return out
    }

    private fun digestName(n: String): String = when (n.uppercase().replace("-", "")) {
        "SHA1" -> "SHA-1"
        "SHA256" -> "SHA-256"
        "SHA384" -> "SHA-384"
        "SHA512" -> "SHA-512"
        "MD5" -> "MD5"
        else -> throw StatementException("This file uses an encryption method the app can't open.")
    }

    private fun digest(name: String, vararg parts: ByteArray): ByteArray {
        val md = MessageDigest.getInstance(name)
        for (p in parts) md.update(p)
        return md.digest()
    }

    /** Cuts to n bytes, or pads with 0x36 as the format requires. */
    private fun fit(b: ByteArray, n: Int): ByteArray =
        if (b.size >= n) b.copyOf(n) else b + ByteArray(n - b.size) { 0x36 }

    private fun cbc(key: ByteArray, iv: ByteArray, data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/CBC/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        return c.doFinal(data.copyOf(data.size - data.size % 16))
    }

    private fun ecb(key: ByteArray, data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/ECB/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"))
        return c.doFinal(data)
    }

    private fun b64(s: String?): ByteArray =
        if (s == null) ByteArray(0) else java.util.Base64.getDecoder().decode(s.trim())

    private fun hex(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    /** True when an old-style .xls workbook is itself password-protected (a FILEPASS record). */
    fun xlsHasPassword(cf: CompoundFile): Boolean {
        val wb = when {
            cf.has("Workbook") -> cf.stream("Workbook")
            cf.has("Book") -> cf.stream("Book")
            else -> return false
        }
        var p = 0
        var n = 0
        while (p + 4 <= wb.size && n++ < 64) {
            val type = (wb[p].toInt() and 0xFF) or ((wb[p + 1].toInt() and 0xFF) shl 8)
            val len = (wb[p + 2].toInt() and 0xFF) or ((wb[p + 3].toInt() and 0xFF) shl 8)
            if (type == 0x002F) return true
            p += 4 + len
        }
        return false
    }
}
