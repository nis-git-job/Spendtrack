package com.spendtrack.app

import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeFormatterBuilder
import java.util.Locale
import java.util.zip.ZipInputStream
import javax.xml.parsers.SAXParserFactory

/** One line of a bank statement. */
data class BankTxn(
    val id: String,
    val time: Long,
    val amount: Double,
    val isDebit: Boolean,
    val merchant: String,
    val category: String,
    val ref: String?,
    val details: String
)

class StatementException(message: String) : Exception(message)

/**
 * Reads a downloaded bank statement (.xlsx, CSV or tab-separated text) into
 * transactions. Pure Kotlin/Java so it can be tested off the phone.
 */
object StatementParser {

    fun parseFile(bytes: ByteArray): List<BankTxn> {
        if (bytes.size < 4) throw StatementException("That file is empty.")
        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        val rows: List<List<String>> = when {
            b0 == 0x50 && b1 == 0x4B -> xlsxRows(bytes)
            b0 == 0xD0 && b1 == 0xCF -> throw StatementException(
                "This is an old-style Excel file (.xls). Open it in Excel or Google Sheets, " +
                    "save it as .xlsx or CSV, and import that file."
            )
            b0 == 0x25 && b1 == 0x50 -> throw StatementException(
                "PDF statements can't be read. Download the statement as Excel or CSV."
            )
            else -> {
                val text = decode(bytes)
                if (text.trimStart().startsWith("<")) throw StatementException(
                    "This file is a web page, not a spreadsheet. Open it in Excel or " +
                        "Google Sheets, save it as .xlsx or CSV, and import that file."
                )
                textRows(text)
            }
        }
        return parseRows(rows)
    }

    // ---------- rows -> transactions ----------

    fun parseRows(rows: List<List<String>>): List<BankTxn> {
        var headerIndex = -1
        var cDate = -1
        var cDetails = -1
        var cRef = -1
        var cDebit = -1
        var cCredit = -1
        for ((i, row) in rows.withIndex()) {
            val cells = row.map { it.trim().lowercase() }
            val date = cells.indexOfFirst { it == "date" || it.contains("txn date") || it.contains("transaction date") }
                .let { if (it >= 0) it else cells.indexOfFirst { c -> c.contains("date") } }
            val debit = cells.indexOfFirst { it.contains("debit") || it.contains("withdraw") || it == "dr" }
            if (date < 0 || debit < 0) continue
            headerIndex = i
            cDate = date
            cDebit = debit
            cCredit = cells.indexOfFirst { it.contains("credit") || it.contains("deposit") || it == "cr" }
            cDetails = cells.indexOfFirst {
                it.contains("detail") || it.contains("description") || it.contains("narration") ||
                    it.contains("particular") || it.contains("remark")
            }
            cRef = cells.indexOfFirst { it.contains("ref") || it.contains("cheque") || it.contains("chq") }
            break
        }
        if (headerIndex < 0) throw StatementException(
            "Couldn't find the Date and Debit columns in this file. " +
                "It needs a header row with columns like Date, Details, Debit, Credit."
        )

        val zone = ZoneId.systemDefault()
        val seen = HashMap<String, Int>()
        val out = ArrayList<BankTxn>()
        for (i in headerIndex + 1 until rows.size) {
            val row = rows[i]
            val date = parseDate(row.getOrNull(cDate) ?: "") ?: continue
            val debit = parseMoney(row.getOrNull(cDebit))
            val credit = if (cCredit >= 0) parseMoney(row.getOrNull(cCredit)) else null
            val isDebit: Boolean
            val amount: Double
            if (debit != null && debit > 0.0) {
                isDebit = true
                amount = debit
            } else if (credit != null && credit > 0.0) {
                isDebit = false
                amount = credit
            } else continue

            val details = (if (cDetails >= 0) row.getOrNull(cDetails) ?: "" else "")
                .replace(Regex("\\s+"), " ").trim()
            val refCell = if (cRef >= 0) row.getOrNull(cRef) ?: "" else ""
            val ref = upiRef.find(details)?.groupValues?.get(1)
                ?: refCell.filter { it.isDigit() }.takeIf { it.length >= 6 }

            val merchant = merchantFrom(details, isDebit)
            val category = when {
                !isDebit -> "Other"
                merchant == LITE -> "UPI Lite"
                merchant == ATM -> "Cash"
                else -> SmsParser.guessCategory(merchant, details)
            }
            val kind = if (isDebit) "D" else "C"
            val base = "b" + kind + (ref ?: Integer.toHexString((date.toString() + "|" + details + "|" + amount).hashCode()))
            val n = (seen[base] ?: 0) + 1
            seen[base] = n
            val id = if (n == 1) base else "$base#$n"
            val time = date.atTime(12, 0).atZone(zone).toInstant().toEpochMilli()
            out.add(BankTxn(id, time, amount, isDebit, merchant, category, ref, details))
        }
        if (out.isEmpty()) throw StatementException("No transactions were found in this file.")
        return out
    }

    private const val LITE = "UPI Lite top-up"
    private const val ATM = "ATM withdrawal"
    private val I = RegexOption.IGNORE_CASE
    private val upiRef = Regex("UPI/(?:DR|CR)/([0-9]{6,16})", I)
    private val upiName = Regex("UPI/(?:DR|CR)/[0-9]+/([^/]+)", I)
    private val branchTail = Regex("\\s+AT\\s+[0-9]+\\s.*$", I)
    private val numberTail = Regex("(\\s+[0-9]{4,})+$")
    private val leadWords = Regex(
        "^(WDL TFR|DEP TFR|BY TRANSFER|TO TRANSFER|CEMTEX DEP|CASH DEP|WDL|DEP|TFR)\\s+", I
    )

    private fun merchantFrom(details: String, isDebit: Boolean): String {
        if (details.replace(" ", "").contains("UPILITE", ignoreCase = true)) return LITE
        val upi = upiName.find(details)?.groupValues?.get(1)
        var s = upi ?: details.replace(leadWords, "")
        if (upi == null && Regex("\\bATM\\b", I).containsMatchIn(details) && isDebit) return ATM
        s = s.replace(branchTail, "").replace(numberTail, "").trim().trim('-', '/', '.', ',')
        if (s.length > 30) s = s.substring(0, 30).trim()
        return if (s.length < 2) (if (isDebit) "Bank payment" else "Money received") else s
    }

    private fun parseMoney(cell: String?): Double? {
        if (cell == null) return null
        val cleaned = cell.filter { it.isDigit() || it == '.' }
        if (cleaned.isEmpty()) return null
        return cleaned.toDoubleOrNull()
    }

    private val dateFormats: List<DateTimeFormatter> = listOf(
        "d-M-uuuu", "d/M/uuuu", "d.M.uuuu", "d-MMM-uuuu", "d MMM uuuu", "d/MMM/uuuu",
        "uuuu-M-d", "d-M-uu", "d/M/uu", "d-MMM-uu", "d MMM uu", "d/MMM/uu"
    ).map {
        DateTimeFormatterBuilder().parseCaseInsensitive().appendPattern(it).toFormatter(Locale.ENGLISH)
    }

    private fun parseDate(cell: String): LocalDate? {
        val text = cell.trim()
        if (text.isEmpty()) return null
        // Excel stores real dates as a day count.
        val serial = text.toDoubleOrNull()
        if (serial != null) {
            return if (serial >= 30000 && serial <= 80000)
                LocalDate.of(1899, 12, 30).plusDays(serial.toLong()) else null
        }
        val candidates = listOf(text, text.substringBefore(' '), text.substringBefore('T'))
        for (c in candidates) {
            for (f in dateFormats) {
                try {
                    return LocalDate.parse(c, f)
                } catch (e: Exception) {
                    // try the next format
                }
            }
        }
        return null
    }

    // ---------- text files (CSV / tab separated) ----------

    private fun decode(bytes: ByteArray): String {
        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        if ((b0 == 0xFF && b1 == 0xFE) || (b0 == 0xFE && b1 == 0xFF)) return String(bytes, Charsets.UTF_16)
        return String(bytes, Charsets.UTF_8).removePrefix("﻿")
    }

    fun textRows(text: String): List<List<String>> {
        val tabbed = text.lineSequence().any { line -> line.count { it == '\t' } >= 3 }
        val sep = if (tabbed) '\t' else ','
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (quoted) {
                if (ch == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') {
                        cell.append('"')
                        i++
                    } else quoted = false
                } else cell.append(ch)
            } else if (ch == '"' && cell.isBlank()) {
                cell.setLength(0)
                quoted = true
            } else if (ch == sep) {
                row.add(cell.toString())
                cell.setLength(0)
            } else if (ch == '\n') {
                row.add(cell.toString())
                cell.setLength(0)
                rows.add(row)
                row = ArrayList()
            } else if (ch != '\r') {
                cell.append(ch)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) {
            row.add(cell.toString())
            rows.add(row)
        }
        return rows
    }

    // ---------- .xlsx (a zip of XML files) ----------

    private fun xlsxRows(bytes: ByteArray): List<List<String>> {
        var shared: ByteArray? = null
        var sheetName: String? = null
        var sheet: ByteArray? = null
        try {
            ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val name = entry.name
                    if (name == "xl/sharedStrings.xml") {
                        shared = readAll(zip)
                    } else if (name.startsWith("xl/worksheets/") && name.endsWith(".xml") &&
                        !name.contains("_rels")
                    ) {
                        val current = sheetName
                        if (current == null || name.length < current.length ||
                            (name.length == current.length && name < current)
                        ) {
                            sheetName = name
                            sheet = readAll(zip)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            throw StatementException("Couldn't open that Excel file. It may be damaged or password-protected.")
        }
        val sheetBytes = sheet ?: throw StatementException("That Excel file has no sheet to read.")

        val strings = ArrayList<String>()
        val sharedBytes = shared
        if (sharedBytes != null) {
            sax(sharedBytes, object : DefaultHandler() {
                val sb = StringBuilder()
                var inT = false
                var inPhonetic = false
                override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                    when (q.substringAfter(':')) {
                        "si" -> sb.setLength(0)
                        "rPh" -> inPhonetic = true
                        "t" -> inT = !inPhonetic
                    }
                }
                override fun endElement(u: String?, l: String?, q: String) {
                    when (q.substringAfter(':')) {
                        "si" -> strings.add(sb.toString())
                        "rPh" -> inPhonetic = false
                        "t" -> inT = false
                    }
                }
                override fun characters(ch: CharArray, start: Int, length: Int) {
                    if (inT) sb.append(ch, start, length)
                }
            })
        }

        val rows = ArrayList<List<String>>()
        sax(sheetBytes, object : DefaultHandler() {
            var row = ArrayList<String>()
            var col = 0
            var type = ""
            val value = StringBuilder()
            var capture = false
            override fun startElement(u: String?, l: String?, q: String, a: Attributes?) {
                when (q.substringAfter(':')) {
                    "row" -> row = ArrayList()
                    "c" -> {
                        type = a?.getValue("t") ?: ""
                        val r = a?.getValue("r")
                        col = if (r != null) columnIndex(r) else row.size
                        value.setLength(0)
                    }
                    "v", "t" -> capture = true
                }
            }
            override fun endElement(u: String?, l: String?, q: String) {
                when (q.substringAfter(':')) {
                    "v", "t" -> capture = false
                    "c" -> {
                        val raw = value.toString()
                        val text = if (type == "s") strings.getOrNull(raw.trim().toIntOrNull() ?: -1) ?: "" else raw
                        while (row.size < col) row.add("")
                        if (row.size == col) row.add(text) else row[col] = text
                    }
                    "row" -> rows.add(row)
                }
            }
            override fun characters(ch: CharArray, start: Int, length: Int) {
                if (capture) value.append(ch, start, length)
            }
        })
        return rows
    }

    private fun columnIndex(cellRef: String): Int {
        var n = 0
        for (ch in cellRef) {
            if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1)
            else if (ch in 'a'..'z') n = n * 26 + (ch - 'a' + 1)
            else break
        }
        return if (n > 0) n - 1 else 0
    }

    private fun readAll(zip: ZipInputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16384)
        while (true) {
            val n = zip.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            if (out.size() > 60_000_000) throw StatementException("That file is too large to read.")
        }
        return out.toByteArray()
    }

    private fun sax(bytes: ByteArray, handler: DefaultHandler) {
        try {
            val factory = SAXParserFactory.newInstance()
            try {
                factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            } catch (e: Exception) {
                // not supported by every parser; the file is still read locally only
            }
            factory.newSAXParser().parse(ByteArrayInputStream(bytes), handler)
        } catch (e: StatementException) {
            throw e
        } catch (e: Exception) {
            throw StatementException("Couldn't read that Excel file.")
        }
    }
}

/** The few facts about an SMS transaction needed to spot it in a statement. */
data class SmsKey(val time: Long, val amount: Double, val isDebit: Boolean, val ref: String?)

/** Outcome of comparing statement lines with SMS. */
class BankMatch(
    /** Statement lines no SMS covers: these get added to the list. */
    val newLines: List<BankTxn>,
    /** Positions in the SMS list that were also found in the statement. */
    val smsAlsoInBank: Set<Int>
)

/**
 * Compares statement lines with SMS so nothing is counted twice. Matches on the
 * UPI reference number first; failing that, on the same amount within a day of
 * each other.
 */
fun matchBankWithSms(bank: List<BankTxn>, sms: List<SmsKey>): BankMatch {
    val used = BooleanArray(sms.size)
    val covered = BooleanArray(bank.size)
    for ((bi, b) in bank.withIndex()) {
        val ref = b.ref ?: continue
        val si = sms.indices.firstOrNull { !used[it] && sms[it].ref == ref && sms[it].isDebit == b.isDebit }
        if (si != null) {
            used[si] = true
            covered[bi] = true
        }
    }
    val day = 24L * 60 * 60 * 1000
    for ((bi, b) in bank.withIndex()) {
        if (covered[bi]) continue
        val si = sms.indices.firstOrNull {
            !used[it] && sms[it].isDebit == b.isDebit &&
                Math.abs(sms[it].amount - b.amount) < 0.005 &&
                Math.abs(sms[it].time - b.time) <= day + day / 2
        }
        if (si != null) {
            used[si] = true
            covered[bi] = true
        }
    }
    val matched = HashSet<Int>()
    for (i in used.indices) if (used[i]) matched.add(i)
    return BankMatch(bank.filterIndexed { i, _ -> !covered[i] }, matched)
}

fun bankLinesNotInSms(bank: List<BankTxn>, sms: List<SmsKey>): List<BankTxn> =
    matchBankWithSms(bank, sms).newLines
