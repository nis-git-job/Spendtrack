package com.spendtrack.app

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Password hashing for the app lock. The password itself is never stored:
 * only a random salt and a slow one-way hash of salt + password.
 */
object Lock {
    private const val ITERATIONS = 50_000
    private const val KEY_BITS = 256

    /** Returns "salt:hash" (both Base64) to store. */
    fun create(password: String): String {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        val enc = Base64.getEncoder()
        return enc.encodeToString(salt) + ":" + enc.encodeToString(hash(password, salt))
    }

    fun matches(password: String, stored: String): Boolean {
        val parts = stored.split(":")
        if (parts.size != 2) return false
        return try {
            val dec = Base64.getDecoder()
            val salt = dec.decode(parts[0])
            val expected = dec.decode(parts[1])
            MessageDigest.isEqual(expected, hash(password, salt))
        } catch (e: Exception) {
            false
        }
    }

    private fun hash(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_BITS)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }
}
