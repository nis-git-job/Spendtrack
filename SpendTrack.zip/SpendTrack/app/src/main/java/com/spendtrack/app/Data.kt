package com.spendtrack.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.time.YearMonth
import java.time.ZoneId

data class Txn(
    val id: String,
    val time: Long,
    val amount: Double,
    val merchant: String,
    val category: String,
    val isDebit: Boolean,
    val excluded: Boolean,
    val body: String,
    val manual: Boolean
)

data class MonthData(
    val txns: List<Txn>,
    val latestBalance: Double?
) {
    val spent: Double get() = txns.filter { it.isDebit && !it.excluded }.sumOf { it.amount }
    val received: Double get() = txns.filter { !it.isDebit && !it.excluded }.sumOf { it.amount }
    val byCategory: List<Pair<String, Double>>
        get() = txns.filter { it.isDebit && !it.excluded }
            .groupBy { it.category }
            .map { it.key to it.value.sumOf { t -> t.amount } }
            .sortedByDescending { it.second }
}

/** Everything the app remembers lives on the phone, in private app storage. */
class Store(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("spendtrack", Context.MODE_PRIVATE)

    var budget: Double
        get() = prefs.getString("budget", "0")?.toDoubleOrNull() ?: 0.0
        set(value) {
            prefs.edit().putString("budget", value.toString()).apply()
        }

    private fun categoryMap(): JSONObject =
        try {
            JSONObject(prefs.getString("categories", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }

    fun categoryFor(id: String): String? {
        val map = categoryMap()
        return if (map.has(id)) map.optString(id) else null
    }

    fun setCategory(id: String, category: String) {
        val map = categoryMap()
        map.put(id, category)
        prefs.edit().putString("categories", map.toString()).apply()
    }

    private fun excludedIds(): Set<String> =
        prefs.getStringSet("excluded", emptySet()) ?: emptySet()

    fun isExcluded(id: String): Boolean = excludedIds().contains(id)

    fun setExcluded(id: String, excluded: Boolean) {
        val copy = HashSet(excludedIds())
        if (excluded) copy.add(id) else copy.remove(id)
        prefs.edit().putStringSet("excluded", copy).apply()
    }

    private fun manualArray(): JSONArray =
        try {
            JSONArray(prefs.getString("manual", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }

    fun addManual(amount: Double, note: String, category: String, time: Long) {
        val arr = manualArray()
        val o = JSONObject()
        o.put("id", "m$time")
        o.put("time", time)
        o.put("amount", amount)
        o.put("note", note)
        o.put("category", category)
        arr.put(o)
        prefs.edit().putString("manual", arr.toString()).apply()
    }

    fun deleteManual(id: String) {
        val arr = manualArray()
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") != id) out.put(o)
        }
        prefs.edit().putString("manual", out.toString()).apply()
    }

    fun manualBetween(start: Long, end: Long): List<Txn> {
        val arr = manualArray()
        val list = ArrayList<Txn>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val time = o.optLong("time")
            if (time < start || time >= end) continue
            val note = o.optString("note")
            list.add(
                Txn(
                    id = o.optString("id"),
                    time = time,
                    amount = o.optDouble("amount", 0.0),
                    merchant = if (note.isBlank()) "Cash expense" else note,
                    category = o.optString("category", "Other"),
                    isDebit = true,
                    excluded = false,
                    body = "",
                    manual = true
                )
            )
        }
        return list
    }
}

/** Reads the SMS inbox for one month and turns bank messages into transactions. */
fun loadMonth(context: Context, store: Store, month: YearMonth): MonthData {
    val zone = ZoneId.systemDefault()
    val start = month.atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
    val end = month.plusMonths(1).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()

    val txns = ArrayList<Txn>()
    var latestBalance: Double? = null

    try {
        val cursor = context.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("_id", "address", "body", "date"),
            "date >= ? AND date < ?",
            arrayOf(start.toString(), end.toString()),
            "date DESC"
        )
        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    val smsId = cursor.getLong(0)
                    val address = cursor.getString(1) ?: ""
                    val body = cursor.getString(2) ?: ""
                    val date = cursor.getLong(3)
                    val parsed = SmsParser.parse(address, body) ?: continue
                    if (latestBalance == null && parsed.balance != null) {
                        latestBalance = parsed.balance
                    }
                    val id = "s$smsId"
                    txns.add(
                        Txn(
                            id = id,
                            time = date,
                            amount = parsed.amount,
                            merchant = parsed.merchant,
                            category = store.categoryFor(id) ?: parsed.category,
                            isDebit = parsed.isDebit,
                            excluded = store.isExcluded(id),
                            body = body,
                            manual = false
                        )
                    )
                }
            } finally {
                cursor.close()
            }
        }
    } catch (e: SecurityException) {
        // Permission was removed while the app was open; show what we have.
    }

    txns.addAll(store.manualBetween(start, end))
    txns.sortByDescending { it.time }
    return MonthData(txns, latestBalance)
}
