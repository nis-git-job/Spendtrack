package com.spendtrack.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

data class Txn(
    val id: String,
    val time: Long,
    val amount: Double,
    val merchant: String,
    val category: String,
    val isDebit: Boolean,
    val excluded: Boolean,
    val body: String,
    val manual: Boolean,
    val fromBank: Boolean = false,
    /** An SMS transaction that was also found in an imported statement. */
    val alsoInBank: Boolean = false,
    /** The user's own note about this transaction. */
    val remark: String = ""
)

data class MonthData(
    val txns: List<Txn>,
    val latestBalance: Double?
) {
    val spent: Double get() = txns.filter { it.isDebit && !it.excluded }.sumOf { it.amount }
    val received: Double get() = txns.filter { !it.isDebit && !it.excluded }.sumOf { it.amount }
    val byCategory: List<Pair<String, Double>>
        get() = txns.filter { it.isDebit && !it.excluded }
            .groupBy { it.category }
            .map { it.key to it.value.sumOf { t -> t.amount } }
            .sortedByDescending { it.second }
}

data class ImportResult(val message: String, val latestMonth: YearMonth?)

/** Everything the app remembers lives on the phone, in private app storage. */
class Store(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("spendtrack", Context.MODE_PRIVATE)
    private val bankFile = File(appContext.filesDir, "bank.json")

    var budget: Double
        get() = prefs.getString("budget", "0")?.toDoubleOrNull() ?: 0.0
        set(value) {
            prefs.edit().putString("budget", value.toString()).apply()
        }

    private fun categoryMap(): JSONObject =
        try {
            JSONObject(prefs.getString("categories", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }

    fun categoryFor(id: String): String? {
        val map = categoryMap()
        return if (map.has(id)) map.optString(id) else null
    }

    fun setCategory(id: String, category: String) {
        val map = categoryMap()
        map.put(id, category)
        prefs.edit().putString("categories", map.toString()).apply()
    }

    // ----- categories the user made -----

    fun customCategories(): List<String> {
        val arr = try {
            JSONArray(prefs.getString("custom_categories", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val name = arr.optString(i).trim()
            if (name.isNotEmpty()) out.add(name)
        }
        return out
    }

    private fun saveCustomCategories(list: List<String>) {
        val arr = JSONArray()
        for (name in list) arr.put(name)
        prefs.edit().putString("custom_categories", arr.toString()).apply()
    }

    /** Built-in categories followed by the user's own. */
    fun allCategories(): List<String> = SmsParser.CATEGORIES + customCategories()

    /** Adds a category. Returns an error message to show, or null when it was added. */
    fun addCategory(raw: String): String? {
        val name = cleanCategoryName(raw)
        if (name.isEmpty()) return "Type a name."
        if (name.length > 20) return "Keep it to 20 characters or fewer."
        if (allCategories().any { it.equals(name, ignoreCase = true) }) {
            return "\"$name\" already exists."
        }
        saveCustomCategories(customCategories() + name)
        return null
    }

    /**
     * Removes one of the user's categories from the list of choices. Payments
     * already filed under it keep the name, so past totals don't change.
     */
    fun removeCategory(name: String) {
        saveCustomCategories(customCategories().filter { it != name })
    }

    private fun remarkMap(): JSONObject =
        try {
            JSONObject(prefs.getString("remarks", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }

    /** All remarks at once, so a month loads without re-reading storage per row. */
    fun allRemarks(): Map<String, String> {
        val map = remarkMap()
        val out = HashMap<String, String>()
        val keys = map.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            out[k] = map.optString(k)
        }
        return out
    }

    fun setRemark(id: String, remark: String) {
        val map = remarkMap()
        val text = remark.trim()
        if (text.isEmpty()) map.remove(id) else map.put(id, text)
        prefs.edit().putString("remarks", map.toString()).apply()
    }

    private fun excludedIds(): Set<String> =
        prefs.getStringSet("excluded", emptySet()) ?: emptySet()

    fun isExcluded(id: String): Boolean = excludedIds().contains(id)

    fun setExcluded(id: String, excluded: Boolean) {
        val copy = HashSet(excludedIds())
        if (excluded) copy.add(id) else copy.remove(id)
        prefs.edit().putStringSet("excluded", copy).apply()
    }

    private fun manualArray(): JSONArray =
        try {
            JSONArray(prefs.getString("manual", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }

    fun addManual(amount: Double, note: String, category: String, time: Long) {
        val arr = manualArray()
        val o = JSONObject()
        o.put("id", "m$time")
        o.put("time", time)
        o.put("amount", amount)
        o.put("note", note)
        o.put("category", category)
        arr.put(o)
        prefs.edit().putString("manual", arr.toString()).apply()
    }

    fun deleteManual(id: String) {
        val arr = manualArray()
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") != id) out.put(o)
        }
        prefs.edit().putString("manual", out.toString()).apply()
    }

    fun manualBetween(start: Long, end: Long): List<Txn> {
        val arr = manualArray()
        val list = ArrayList<Txn>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val time = o.optLong("time")
            if (time < start || time >= end) continue
            val note = o.optString("note")
            list.add(
                Txn(
                    id = o.optString("id"),
                    time = time,
                    amount = o.optDouble("amount", 0.0),
                    merchant = if (note.isBlank()) "Cash expense" else note,
                    category = o.optString("category", "Other"),
                    isDebit = true,
                    excluded = false,
                    body = "",
                    manual = true
                )
            )
        }
        return list
    }

    // ----- app password -----

    fun hasPassword(): Boolean = !prefs.getString("lock", null).isNullOrEmpty()

    fun setPassword(password: String) {
        prefs.edit().putString("lock", Lock.create(password))
            .putInt("lock_fails", 0).putLong("lock_until", 0L).apply()
    }

    fun clearPassword() {
        prefs.edit().remove("lock").putInt("lock_fails", 0).putLong("lock_until", 0L).apply()
    }

    /** Plain check, used when the app is already open. */
    fun passwordMatches(password: String): Boolean {
        val stored = prefs.getString("lock", null) ?: return false
        return Lock.matches(password, stored)
    }

    /** Seconds left before another unlock attempt is allowed (0 = allowed now). */
    fun lockWaitSeconds(): Int {
        val until = prefs.getLong("lock_until", 0L)
        val left = until - System.currentTimeMillis()
        return if (left > 0) ((left + 999) / 1000).toInt() else 0
    }

    /** Unlock attempt. Five wrong tries in a row cause a 30 second wait. */
    fun tryUnlock(password: String): Boolean {
        if (passwordMatches(password)) {
            prefs.edit().putInt("lock_fails", 0).putLong("lock_until", 0L).apply()
            return true
        }
        val fails = prefs.getInt("lock_fails", 0) + 1
        if (fails >= 5) {
            prefs.edit().putInt("lock_fails", 0)
                .putLong("lock_until", System.currentTimeMillis() + 30_000L).apply()
        } else {
            prefs.edit().putInt("lock_fails", fails).apply()
        }
        return false
    }

    // ----- imported bank statement lines -----

    @Synchronized
    fun bankAll(): List<BankTxn> {
        if (!bankFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(bankFile.readText())
            val list = ArrayList<BankTxn>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    BankTxn(
                        id = o.getString("id"),
                        time = o.getLong("time"),
                        amount = o.getDouble("amount"),
                        isDebit = o.getBoolean("debit"),
                        merchant = o.optString("merchant", "Bank payment"),
                        category = o.optString("category", "Other"),
                        ref = if (o.has("ref")) o.getString("ref") else null,
                        details = o.optString("details", "")
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Adds statement lines, replacing any that were imported before. Returns how many were new. */
    @Synchronized
    fun mergeBank(rows: List<BankTxn>): Int {
        // Lines saved by an older reader may carry wrong dates (Excel's day/month
        // mix-up was not corrected before reader 2). Drop them so this import
        // replaces them instead of sitting next to them.
        if (prefs.getInt("bank_reader", 1) < BANK_READER) {
            if (bankFile.exists()) bankFile.delete()
            prefs.edit().putInt("bank_reader", BANK_READER).apply()
        }
        val byId = LinkedHashMap<String, BankTxn>()
        for (t in bankAll()) byId[t.id] = t
        var added = 0
        for (t in rows) {
            if (!byId.containsKey(t.id)) added++
            byId[t.id] = t
        }
        val arr = JSONArray()
        for (t in byId.values) {
            val o = JSONObject()
            o.put("id", t.id)
            o.put("time", t.time)
            o.put("amount", t.amount)
            o.put("debit", t.isDebit)
            o.put("merchant", t.merchant)
            o.put("category", t.category)
            if (t.ref != null) o.put("ref", t.ref)
            o.put("details", t.details)
            arr.put(o)
        }
        bankFile.writeText(arr.toString())
        return added
    }

    @Synchronized
    fun bankCount(): Int = bankAll().size

    @Synchronized
    fun clearBank() {
        if (bankFile.exists()) bankFile.delete()
    }
}

private const val BANK_READER = 2

/** Trims a category name and collapses repeated spaces. */
fun cleanCategoryName(raw: String): String = raw.trim().replace(Regex("\\s+"), " ")

/** Reads a statement file the user picked and saves its lines. Never throws. */
fun importStatement(context: Context, store: Store, uri: Uri): ImportResult {
    return try {
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(16384)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                if (out.size() > 30_000_000) throw StatementException("That file is too large to read.")
            }
            out.toByteArray()
        } ?: throw StatementException("Couldn't open that file.")

        val rows = StatementParser.parseFile(bytes)
        val added = store.mergeBank(rows)
        val zone = ZoneId.systemDefault()
        val fmt = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)
        val first = Instant.ofEpochMilli(rows.minOf { it.time }).atZone(zone).toLocalDate()
        val last = Instant.ofEpochMilli(rows.maxOf { it.time }).atZone(zone).toLocalDate()
        val already = rows.size - added
        val message = "Read " + rows.size + " statement lines from " + first.format(fmt) +
            " to " + last.format(fmt) + "." +
            (if (already > 0) " " + already + " were imported before and were not added again." else "") +
            " Payments the app already knows from SMS are not counted twice."
        ImportResult(message, YearMonth.from(last))
    } catch (e: StatementException) {
        ImportResult(e.message ?: "Couldn't read that file.", null)
    } catch (e: Exception) {
        ImportResult("Couldn't read that file.", null)
    }
}

/** Builds one month from SMS, imported statement lines and manual entries. */
fun loadMonth(context: Context, store: Store, month: YearMonth): MonthData {
    val zone = ZoneId.systemDefault()
    val start = month.atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
    val end = month.plusMonths(1).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
    // Look a few days either side too, so an SMS just outside the month can
    // still be matched with its statement line.
    val margin = 3L * 24 * 60 * 60 * 1000

    val txns = ArrayList<Txn>()
    val smsKeys = ArrayList<SmsKey>()
    val txnIndexOfSms = HashMap<Int, Int>()
    var latestBalance: Double? = null

    try {
        val cursor = context.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("_id", "address", "body", "date"),
            "date >= ? AND date < ?",
            arrayOf((start - margin).toString(), (end + margin).toString()),
            "date DESC"
        )
        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    val smsId = cursor.getLong(0)
                    val address = cursor.getString(1) ?: ""
                    val body = cursor.getString(2) ?: ""
                    val date = cursor.getLong(3)
                    val parsed = SmsParser.parse(address, body) ?: continue
                    smsKeys.add(SmsKey(date, parsed.amount, parsed.isDebit, parsed.ref))
                    if (date < start || date >= end) continue
                    txnIndexOfSms[smsKeys.size - 1] = txns.size
                    if (latestBalance == null && parsed.balance != null) {
                        latestBalance = parsed.balance
                    }
                    val id = "s$smsId"
                    txns.add(
                        Txn(
                            id = id,
                            time = date,
                            amount = parsed.amount,
                            merchant = parsed.merchant,
                            category = store.categoryFor(id) ?: parsed.category,
                            isDebit = parsed.isDebit,
                            excluded = store.isExcluded(id),
                            body = body,
                            manual = false
                        )
                    )
                }
            } finally {
                cursor.close()
            }
        }
    } catch (e: SecurityException) {
        // Permission was removed while the app was open; show what we have.
    }

    val bankInMonth = store.bankAll().filter { it.time >= start && it.time < end }
    val match = matchBankWithSms(bankInMonth, smsKeys)
    for (smsIndex in match.smsAlsoInBank) {
        val at = txnIndexOfSms[smsIndex] ?: continue
        txns[at] = txns[at].copy(alsoInBank = true)
    }
    for (b in match.newLines) {
        txns.add(
            Txn(
                id = b.id,
                time = b.time,
                amount = b.amount,
                merchant = b.merchant,
                category = store.categoryFor(b.id) ?: b.category,
                isDebit = b.isDebit,
                excluded = store.isExcluded(b.id),
                body = b.details,
                manual = false,
                fromBank = true
            )
        )
    }

    txns.addAll(store.manualBetween(start, end))
    val remarks = store.allRemarks()
    if (remarks.isNotEmpty()) {
        for (i in txns.indices) {
            val remark = remarks[txns[i].id]
            if (remark != null) txns[i] = txns[i].copy(remark = remark)
        }
    }
    txns.sortByDescending { it.time }
    return MonthData(txns, latestBalance)
}
