package com.spendtrack.app

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

data class Txn(
    val id: String,
    val time: Long,
    val amount: Double,
    val merchant: String,
    val category: String,
    val isDebit: Boolean,
    val excluded: Boolean,
    val body: String,
    val manual: Boolean,
    val fromBank: Boolean = false,
    /** An SMS transaction that was also found in an imported statement. */
    val alsoInBank: Boolean = false,
    /** The user's own note about this transaction. */
    val remark: String = "",
    /** Added from a Google Pay statement (nothing else had it). */
    val fromGpay: Boolean = false,
    /** An SMS or statement line that a Google Pay statement also lists. */
    val alsoInGpay: Boolean = false,
    /**
     * A UPI Lite top-up inside a period covered by a Google Pay statement. It is
     * not counted, because each UPI Lite payment from that statement is counted.
     */
    val liteCovered: Boolean = false,
    /**
     * An SMS debit dated within an imported bank statement that the statement
     * doesn't list. Left out of totals until the user decides.
     */
    val notInStatement: Boolean = false,
    /** The user has looked at a notInStatement payment and decided. */
    val reviewed: Boolean = false,
    /** When this credit is the salary: the month it pays for. */
    val salaryFor: YearMonth? = null
)

data class MonthData(
    val txns: List<Txn>,
    val latestBalance: Double?,
    /** When the SMS carrying latestBalance arrived. */
    val latestBalanceTime: Long? = null,
    /** Salary for this month (usually credited at the end of the month before). */
    val salary: Credit? = null
) {
    val spent: Double get() = txns.filter { it.isDebit && !it.excluded }.sumOf { it.amount }
    /** Money in, not counting a salary: that belongs to the month it pays for. */
    val received: Double get() = txns.filter { !it.isDebit && !it.excluded && it.salaryFor == null }.sumOf { it.amount }
    val byCategory: List<Pair<String, Double>>
        get() = txns.filter { it.isDebit && !it.excluded }
            .groupBy { it.category }
            .map { it.key to it.value.sumOf { t -> t.amount } }
            .sortedByDescending { it.second }
}

data class ImportResult(
    val message: String,
    val latestMonth: YearMonth?,
    /** The file is locked: ask for its password and try again. */
    val needsPassword: Boolean = false
)

/** Everything the app remembers lives on the phone, in private app storage. */
class Store(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("spendtrack", Context.MODE_PRIVATE)
    private val bankFile = File(appContext.filesDir, "bank.json")
    private val gpayFile = File(appContext.filesDir, "gpay.json")

    var budget: Double
        get() = prefs.getString("budget", "0")?.toDoubleOrNull() ?: 0.0
        set(value) {
            prefs.edit().putString("budget", value.toString()).apply()
        }

    private fun categoryMap(): JSONObject =
        try {
            JSONObject(prefs.getString("categories", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }

    fun categoryFor(id: String): String? {
        val map = categoryMap()
        return if (map.has(id)) map.optString(id) else null
    }

    fun setCategory(id: String, category: String) {
        val map = categoryMap()
        map.put(id, category)
        prefs.edit().putString("categories", map.toString()).apply()
    }

    // ----- bank statement coverage and payments to check -----

    /** (first day, last day, when imported) of each bank statement imported. */
    fun bankPeriods(): List<Triple<LocalDate, LocalDate, Long>> {
        val arr = try {
            JSONArray(prefs.getString("bank_periods", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<Triple<LocalDate, LocalDate, Long>>()
        for (i in 0 until arr.length()) {
            val p = arr.optJSONArray(i) ?: continue
            out.add(Triple(LocalDate.ofEpochDay(p.optLong(0)), LocalDate.ofEpochDay(p.optLong(1)), p.optLong(2)))
        }
        if (out.isEmpty()) {
            // Statements imported before periods were recorded: use the dates they span.
            val lines = bankAll()
            if (lines.isNotEmpty()) {
                val zone = ZoneId.systemDefault()
                val days = lines.map { Instant.ofEpochMilli(it.time).atZone(zone).toLocalDate() }
                val at = if (lastImportTime > 0L) lastImportTime else System.currentTimeMillis()
                out.add(Triple(days.minOrNull()!!, days.maxOrNull()!!, at))
            }
        }
        return out
    }

    fun addBankPeriod(first: LocalDate, last: LocalDate, importedAt: Long) {
        val arr = try {
            JSONArray(prefs.getString("bank_periods", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        val one = JSONArray()
        one.put(first.toEpochDay())
        one.put(last.toEpochDay())
        one.put(importedAt)
        arr.put(one)
        prefs.edit().putString("bank_periods", arr.toString()).apply()
    }

    private fun reviewMap(): JSONObject =
        try {
            JSONObject(prefs.getString("reviews", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }

    /** "count", "skip", or null if the user hasn't decided. */
    fun reviewFor(id: String): String? {
        val m = reviewMap()
        return if (m.has(id)) m.optString(id) else null
    }

    /** SMS entries the user deleted from the app (the SMS itself stays in Messages). */
    fun deletedSms(): Set<String> = prefs.getStringSet("deleted_sms", emptySet()) ?: emptySet()

    fun deleteSms(ids: Collection<String>) {
        val set = HashSet(deletedSms())
        set.addAll(ids)
        prefs.edit().putStringSet("deleted_sms", set).apply()
    }

    fun restoreDeletedSms() {
        prefs.edit().remove("deleted_sms").apply()
    }

    fun setReview(id: String, decision: String) {
        val m = reviewMap()
        m.put(id, decision)
        prefs.edit().putString("reviews", m.toString()).apply()
    }

    // ----- salary -----

    fun salaryHints(): SalaryHints = SalaryHints(
        yes = prefs.getStringSet("salary_yes", emptySet()) ?: emptySet(),
        no = prefs.getStringSet("salary_no", emptySet()) ?: emptySet(),
        tokens = prefs.getStringSet("salary_tokens", emptySet()) ?: emptySet(),
        lastAmount = prefs.getString("salary_last", null)?.toDoubleOrNull()
    )

    /** isSalary: true = "This is my salary", false = "Not my salary". */
    fun markSalary(id: String, isSalary: Boolean, details: String) {
        val yes = HashSet(prefs.getStringSet("salary_yes", emptySet()) ?: emptySet())
        val no = HashSet(prefs.getStringSet("salary_no", emptySet()) ?: emptySet())
        val tokens = HashSet(prefs.getStringSet("salary_tokens", emptySet()) ?: emptySet())
        if (isSalary) {
            yes.add(id)
            no.remove(id)
            tokens.addAll(SalaryFinder.tokens(details))
        } else {
            no.add(id)
            yes.remove(id)
        }
        prefs.edit().putStringSet("salary_yes", yes).putStringSet("salary_no", no)
            .putStringSet("salary_tokens", tokens).apply()
    }

    /** Remembers the latest salary found, so next month's can be recognised by amount. */
    fun noteSalary(month: YearMonth, amount: Double) {
        val known = prefs.getString("salary_last_month", null)
        if (known == null || month.toString() >= known) {
            prefs.edit().putString("salary_last", amount.toString())
                .putString("salary_last_month", month.toString()).apply()
        }
    }

    // ----- statement password and reminders -----

    /** Password for locked statement files, if the user chose to remember it. */
    var statementPassword: String?
        get() = prefs.getString("st_pw", null)
        set(value) {
            if (value == null) prefs.edit().remove("st_pw").apply()
            else prefs.edit().putString("st_pw", value).apply()
        }

    var lastImportTime: Long
        get() = prefs.getLong("last_import", 0L)
        set(value) {
            prefs.edit().putLong("last_import", value).apply()
        }

    var remindersOn: Boolean
        get() = prefs.getBoolean("reminders", true)
        set(value) {
            prefs.edit().putBoolean("reminders", value).apply()
        }

    /** When reminders started counting, for someone who has never imported. */
    var reminderSince: Long
        get() = prefs.getLong("reminder_since", 0L)
        set(value) {
            prefs.edit().putLong("reminder_since", value).apply()
        }

    var lastReminded: Long
        get() = prefs.getLong("last_reminded", 0L)
        set(value) {
            prefs.edit().putLong("last_reminded", value).apply()
        }

    var notificationAsked: Boolean
        get() = prefs.getBoolean("notif_asked", false)
        set(value) {
            prefs.edit().putBoolean("notif_asked", value).apply()
        }

    // ----- categories the user made -----

    fun customCategories(): List<String> {
        val arr = try {
            JSONArray(prefs.getString("custom_categories", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val name = arr.optString(i).trim()
            if (name.isNotEmpty()) out.add(name)
        }
        return out
    }

    private fun saveCustomCategories(list: List<String>) {
        val arr = JSONArray()
        for (name in list) arr.put(name)
        prefs.edit().putString("custom_categories", arr.toString()).apply()
    }

    private fun savedOrder(): List<String> {
        val arr = try {
            JSONArray(prefs.getString("category_order", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) out.add(arr.optString(i))
        return out
    }

    /** Every category, built-in and the user's own, in the order the user chose. */
    fun allCategories(): List<String> {
        val known = SmsParser.CATEGORIES + customCategories()
        val saved = savedOrder().filter { it in known }.distinct()
        return saved + known.filter { it !in saved }
    }

    /** Moves a category one place earlier (delta -1) or later (delta +1). */
    fun moveCategory(name: String, delta: Int) {
        val list = allCategories().toMutableList()
        val i = list.indexOf(name)
        val j = i + delta
        if (i < 0 || j < 0 || j >= list.size) return
        list[i] = list[j]
        list[j] = name
        val arr = JSONArray()
        for (c in list) arr.put(c)
        prefs.edit().putString("category_order", arr.toString()).apply()
    }

    /** Adds a category. Returns an error message to show, or null when it was added. */
    fun addCategory(raw: String): String? {
        val name = cleanCategoryName(raw)
        if (name.isEmpty()) return "Type a name."
        if (name.length > 20) return "Keep it to 20 characters or fewer."
        if (allCategories().any { it.equals(name, ignoreCase = true) }) {
            return "\"$name\" already exists."
        }
        saveCustomCategories(customCategories() + name)
        return null
    }

    /**
     * Removes one of the user's categories from the list of choices. Payments
     * already filed under it keep the name, so past totals don't change.
     */
    fun removeCategory(name: String) {
        saveCustomCategories(customCategories().filter { it != name })
    }

    private fun remarkMap(): JSONObject =
        try {
            JSONObject(prefs.getString("remarks", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }

    /** All remarks at once, so a month loads without re-reading storage per row. */
    fun allRemarks(): Map<String, String> {
        val map = remarkMap()
        val out = HashMap<String, String>()
        val keys = map.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            out[k] = map.optString(k)
        }
        return out
    }

    fun setRemark(id: String, remark: String) {
        val map = remarkMap()
        val text = remark.trim()
        if (text.isEmpty()) map.remove(id) else map.put(id, text)
        prefs.edit().putString("remarks", map.toString()).apply()
    }

    private fun excludedIds(): Set<String> =
        prefs.getStringSet("excluded", emptySet()) ?: emptySet()

    fun isExcluded(id: String): Boolean = excludedIds().contains(id)

    fun setExcluded(id: String, excluded: Boolean) {
        val copy = HashSet(excludedIds())
        if (excluded) copy.add(id) else copy.remove(id)
        prefs.edit().putStringSet("excluded", copy).apply()
    }

    private fun manualArray(): JSONArray =
        try {
            JSONArray(prefs.getString("manual", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }

    fun addManual(amount: Double, note: String, category: String, time: Long) {
        val arr = manualArray()
        val o = JSONObject()
        // The id uses the moment of saving, so entries back-dated to the same day stay distinct.
        o.put("id", "m" + System.currentTimeMillis())
        o.put("time", time)
        o.put("amount", amount)
        o.put("note", note)
        o.put("category", category)
        arr.put(o)
        prefs.edit().putString("manual", arr.toString()).apply()
    }

    fun deleteManual(id: String) {
        val arr = manualArray()
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") != id) out.put(o)
        }
        prefs.edit().putString("manual", out.toString()).apply()
    }

    fun manualBetween(start: Long, end: Long): List<Txn> {
        val arr = manualArray()
        val list = ArrayList<Txn>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val time = o.optLong("time")
            if (time < start || time >= end) continue
            val note = o.optString("note")
            list.add(
                Txn(
                    id = o.optString("id"),
                    time = time,
                    amount = o.optDouble("amount", 0.0),
                    merchant = if (note.isBlank()) "Cash expense" else note,
                    category = o.optString("category", "Other"),
                    isDebit = true,
                    excluded = false,
                    body = "",
                    manual = true
                )
            )
        }
        return list
    }

    // ----- app password -----

    fun hasPassword(): Boolean = !prefs.getString("lock", null).isNullOrEmpty()

    fun setPassword(password: String) {
        prefs.edit().putString("lock", Lock.create(password))
            .putInt("lock_fails", 0).putLong("lock_until", 0L).apply()
    }

    fun clearPassword() {
        prefs.edit().remove("lock").putInt("lock_fails", 0).putLong("lock_until", 0L).apply()
    }

    /** Plain check, used when the app is already open. */
    fun passwordMatches(password: String): Boolean {
        val stored = prefs.getString("lock", null) ?: return false
        return Lock.matches(password, stored)
    }

    /** Seconds left before another unlock attempt is allowed (0 = allowed now). */
    fun lockWaitSeconds(): Int {
        val until = prefs.getLong("lock_until", 0L)
        val left = until - System.currentTimeMillis()
        return if (left > 0) ((left + 999) / 1000).toInt() else 0
    }

    /** Unlock attempt. Five wrong tries in a row cause a 30 second wait. */
    fun tryUnlock(password: String): Boolean {
        if (passwordMatches(password)) {
            prefs.edit().putInt("lock_fails", 0).putLong("lock_until", 0L).apply()
            return true
        }
        val fails = prefs.getInt("lock_fails", 0) + 1
        if (fails >= 5) {
            prefs.edit().putInt("lock_fails", 0)
                .putLong("lock_until", System.currentTimeMillis() + 30_000L).apply()
        } else {
            prefs.edit().putInt("lock_fails", fails).apply()
        }
        return false
    }

    // ----- imported bank statement lines -----

    @Synchronized
    fun bankAll(): List<BankTxn> {
        if (!bankFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(bankFile.readText())
            val list = ArrayList<BankTxn>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    BankTxn(
                        id = o.getString("id"),
                        time = o.getLong("time"),
                        amount = o.getDouble("amount"),
                        isDebit = o.getBoolean("debit"),
                        merchant = o.optString("merchant", "Bank payment"),
                        category = o.optString("category", "Other"),
                        ref = if (o.has("ref")) o.getString("ref") else null,
                        details = o.optString("details", ""),
                        balance = if (o.has("balance")) o.getDouble("balance") else null
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Adds statement lines, replacing any that were imported before. Returns how many were new. */
    @Synchronized
    fun mergeBank(rows: List<BankTxn>): Int {
        // Lines saved by an older reader may carry wrong dates (Excel's day/month
        // mix-up was not corrected before reader 2). Drop them so this import
        // replaces them instead of sitting next to them.
        if (prefs.getInt("bank_reader", 1) < BANK_READER) {
            if (bankFile.exists()) bankFile.delete()
            prefs.edit().putInt("bank_reader", BANK_READER).apply()
        }
        val byId = LinkedHashMap<String, BankTxn>()
        for (t in bankAll()) byId[t.id] = t
        var added = 0
        for (t in rows) {
            if (!byId.containsKey(t.id)) added++
            byId[t.id] = t
        }
        val arr = JSONArray()
        for (t in byId.values) {
            val o = JSONObject()
            o.put("id", t.id)
            o.put("time", t.time)
            o.put("amount", t.amount)
            o.put("debit", t.isDebit)
            o.put("merchant", t.merchant)
            o.put("category", t.category)
            if (t.ref != null) o.put("ref", t.ref)
            o.put("details", t.details)
            if (t.balance != null) o.put("balance", t.balance)
            arr.put(o)
        }
        bankFile.writeText(arr.toString())
        return added
    }

    @Synchronized
    fun bankCount(): Int = bankAll().size + gpayAll().size

    /** Removes every imported statement: bank and Google Pay. */
    @Synchronized
    fun clearBank() {
        if (bankFile.exists()) bankFile.delete()
        if (gpayFile.exists()) gpayFile.delete()
        prefs.edit().remove("gpay_periods").remove("st_bal").remove("st_bal_time")
            .remove("bank_periods").apply()
    }

    /** Closing balance of the most recent bank statement imported, with its date. */
    fun statementBalance(): Pair<Double, Long>? {
        val time = prefs.getLong("st_bal_time", -1L)
        if (time < 0) return null
        val amount = prefs.getString("st_bal", null)?.toDoubleOrNull() ?: return null
        return amount to time
    }

    /** Keeps the balance only if it is at least as recent as the one stored. */
    fun saveStatementBalance(amount: Double, time: Long) {
        val current = statementBalance()
        if (current != null && time < current.second) return
        prefs.edit().putString("st_bal", amount.toString()).putLong("st_bal_time", time).apply()
    }

    // ----- imported Google Pay statements -----

    @Synchronized
    fun gpayAll(): List<GpayTxn> {
        if (!gpayFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(gpayFile.readText())
            val list = ArrayList<GpayTxn>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    GpayTxn(
                        id = o.getString("id"),
                        time = o.getLong("time"),
                        amount = o.getDouble("amount"),
                        kind = GpayKind.valueOf(o.optString("kind", "PAYMENT")),
                        name = o.optString("name", "Google Pay payment"),
                        viaLite = o.optBoolean("lite", false),
                        ref = if (o.has("ref")) o.getString("ref") else null,
                        category = o.optString("category", "Other")
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Days covered by imported Google Pay statements, as (first day, last day). */
    fun gpayPeriods(): List<Pair<LocalDate, LocalDate>> {
        val arr = try {
            JSONArray(prefs.getString("gpay_periods", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<Pair<LocalDate, LocalDate>>()
        for (i in 0 until arr.length()) {
            val p = arr.optJSONArray(i) ?: continue
            out.add(LocalDate.ofEpochDay(p.optLong(0)) to LocalDate.ofEpochDay(p.optLong(1)))
        }
        return out
    }

    /** Saves a Google Pay statement, replacing entries imported before. Returns how many were new. */
    @Synchronized
    fun mergeGpay(statement: GpayStatement): Int {
        val byId = LinkedHashMap<String, GpayTxn>()
        for (t in gpayAll()) byId[t.id] = t
        var added = 0
        for (t in statement.txns) {
            if (!byId.containsKey(t.id)) added++
            byId[t.id] = t
        }
        val arr = JSONArray()
        for (t in byId.values) {
            val o = JSONObject()
            o.put("id", t.id)
            o.put("time", t.time)
            o.put("amount", t.amount)
            o.put("kind", t.kind.name)
            o.put("name", t.name)
            o.put("lite", t.viaLite)
            if (t.ref != null) o.put("ref", t.ref)
            o.put("category", t.category)
            arr.put(o)
        }
        gpayFile.writeText(arr.toString())

        val periods = gpayPeriods().toMutableList()
        val p = statement.from to statement.to
        if (p !in periods) periods.add(p)
        val pa = JSONArray()
        for ((a, b) in periods) {
            val one = JSONArray()
            one.put(a.toEpochDay())
            one.put(b.toEpochDay())
            pa.put(one)
        }
        prefs.edit().putString("gpay_periods", pa.toString()).apply()
        return added
    }
}

/** Extracts the text of a PDF with PdfBox. */
private fun pdfText(context: Context, bytes: ByteArray, password: String?): String {
    PDFBoxResourceLoader.init(context.applicationContext)
    try {
        PDDocument.load(bytes, password ?: "").use { doc ->
            val stripper = PDFTextStripper()
            stripper.sortByPosition = true
            return stripper.getText(doc)
        }
    } catch (e: InvalidPasswordException) {
        if (password == null) throw StatementPasswordNeeded() else throw StatementWrongPassword()
    }
}

private fun importGpay(context: Context, store: Store, bytes: ByteArray, password: String?): ImportResult {
    val text = pdfText(context, bytes, password)
    if (!GpayParser.looksLikeGpay(text)) throw StatementException(
        "This PDF isn't a Google Pay transaction statement. For a bank statement, " +
            "download it as Excel (.xlsx) or CSV instead."
    )
    val st = GpayParser.parse(text)
    val added = store.mergeGpay(st)
    val fmt = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)
    val pay = st.txns.filter { it.kind == GpayKind.PAYMENT }
    val lite = pay.count { it.viaLite }
    val topups = st.txns.count { it.kind == GpayKind.TOPUP }
    val already = st.txns.size - added
    val message = "Read Google Pay statement for " + st.from.format(fmt) + " to " + st.to.format(fmt) +
        ": " + pay.size + " payments (" + lite + " from UPI Lite), " + topups + " UPI Lite top-ups." +
        (if (already > 0) " " + already + " were imported before and were not added again." else "") +
        " Payments already known from SMS or a bank statement are not counted twice." +
        (if (topups > 0 || lite > 0) " For these dates UPI Lite top-ups are no longer counted as " +
            "spending, because each UPI Lite payment is counted instead." else "")
    return ImportResult(message, YearMonth.from(st.to))
}

private const val BANK_READER = 2

/** Trims a category name and collapses repeated spaces. */
fun cleanCategoryName(raw: String): String = raw.trim().replace(Regex("\\s+"), " ")

/** Reads a statement file the user picked and saves its lines. Never throws. */
/**
 * password: what the user typed for a locked file (null on the first try, when a
 * remembered password is tried instead). remember: save the typed password.
 */
fun importStatement(
    context: Context,
    store: Store,
    uri: Uri,
    password: String? = null,
    remember: Boolean = false
): ImportResult {
    val saved = store.statementPassword
    val pw = password ?: saved
    fun done(r: ImportResult): ImportResult {
        if (password != null && remember) store.statementPassword = password
        store.lastImportTime = System.currentTimeMillis()
        return r
    }
    return try {
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(16384)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                if (out.size() > 30_000_000) throw StatementException("That file is too large to read.")
            }
            out.toByteArray()
        } ?: throw StatementException("Couldn't open that file.")

        if (bytes.size > 4 && bytes[0] == 0x25.toByte() && bytes[1] == 0x50.toByte() &&
            bytes[2] == 0x44.toByte() && bytes[3] == 0x46.toByte()
        ) {
            return done(importGpay(context, store, bytes, pw))
        }
        val rows = StatementParser.parseFile(bytes, pw)
        val added = store.mergeBank(rows)
        val closing = closingBalance(rows)
        if (closing?.balance != null) store.saveStatementBalance(closing.balance, closing.time)
        val zone = ZoneId.systemDefault()
        val fmt = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)
        val first = Instant.ofEpochMilli(rows.minOf { it.time }).atZone(zone).toLocalDate()
        val last = Instant.ofEpochMilli(rows.maxOf { it.time }).atZone(zone).toLocalDate()
        store.addBankPeriod(first, last, System.currentTimeMillis())
        val already = rows.size - added
        val message = "Read " + rows.size + " statement lines from " + first.format(fmt) +
            " to " + last.format(fmt) + "." +
            (if (already > 0) " " + already + " were imported before and were not added again." else "") +
            " Payments the app already knows from SMS are not counted twice."
        done(ImportResult(message, YearMonth.from(last)))
    } catch (e: StatementPasswordNeeded) {
        ImportResult(e.message ?: "This file is password-protected.", null, needsPassword = true)
    } catch (e: StatementWrongPassword) {
        val msg = if (password == null && saved != null)
            "The saved password didn't open this file. Enter its password."
        else e.message ?: "That password didn't open the file."
        ImportResult(msg, null, needsPassword = true)
    } catch (e: StatementException) {
        ImportResult(e.message ?: "Couldn't read that file.", null)
    } catch (e: Exception) {
        ImportResult("Couldn't read that file.", null)
    }
}

/** Builds one month from SMS, imported statement lines and manual entries. */
fun loadMonth(context: Context, store: Store, month: YearMonth): MonthData {
    val zone = ZoneId.systemDefault()
    val start = month.atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
    val end = month.plusMonths(1).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
    val data = loadBetween(context, store, start, end)
    return data.copy(salary = findSalary(context, store, month))
}

/** Credits that could be month M's salary: statement lines and SMS in its window. */
private fun salaryCandidates(context: Context, store: Store, payMonth: YearMonth): List<Credit> {
    val zone = ZoneId.systemDefault()
    val (a, b) = SalaryFinder.window(payMonth)
    val from = a.atStartOfDay(zone).toInstant().toEpochMilli()
    val to = b.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
    val out = ArrayList<Credit>()
    for (t in store.bankAll()) {
        if (!t.isDebit && t.time >= from && t.time < to) out.add(Credit(t.id, t.time, t.amount, t.details, true))
    }
    try {
        context.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("_id", "address", "body", "date"),
            "date >= ? AND date < ?",
            arrayOf(from.toString(), to.toString()),
            null
        )?.use { c ->
            while (c.moveToNext()) {
                val body = c.getString(2) ?: ""
                val p = SmsParser.parse(c.getString(1) ?: "", body) ?: continue
                if (!p.isDebit) out.add(Credit("s" + c.getLong(0), c.getLong(3), p.amount, body, false))
            }
        }
    } catch (e: SecurityException) {
        // no SMS access: statement lines only
    }
    return out
}

/** The salary for month M, or null if none is found. */
fun findSalary(context: Context, store: Store, payMonth: YearMonth): Credit? {
    val s = SalaryFinder.find(salaryCandidates(context, store, payMonth), payMonth, store.salaryHints(), ZoneId.systemDefault())
    if (s != null) store.noteSalary(payMonth, s.amount)
    return s
}

/** Builds the days from first to last (inclusive), which may span several months. */
fun loadDays(context: Context, store: Store, first: LocalDate, last: LocalDate): MonthData {
    val zone = ZoneId.systemDefault()
    val start = first.atStartOfDay(zone).toInstant().toEpochMilli()
    val end = last.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
    return loadBetween(context, store, start, end)
}

/** Everything between two moments (start included, end not). */
fun loadBetween(context: Context, store: Store, start: Long, end: Long): MonthData {
    val zone = ZoneId.systemDefault()
    // Look a few days either side too, so an SMS just outside the month can
    // still be matched with its statement line.
    val margin = 3L * 24 * 60 * 60 * 1000

    val txns = ArrayList<Txn>()
    val smsKeys = ArrayList<SmsKey>()
    val deleted = store.deletedSms()
    val txnIndexOfSms = HashMap<Int, Int>()
    var latestBalance: Double? = null
    var latestBalanceTime: Long? = null

    try {
        val cursor = context.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("_id", "address", "body", "date"),
            "date >= ? AND date < ?",
            arrayOf((start - margin).toString(), (end + margin).toString()),
            "date DESC"
        )
        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    val smsId = cursor.getLong(0)
                    val address = cursor.getString(1) ?: ""
                    val body = cursor.getString(2) ?: ""
                    val date = cursor.getLong(3)
                    val parsed = SmsParser.parse(address, body) ?: continue
                    // Deleted by the user: as if the SMS never came.
                    if (deleted.contains("s$smsId")) continue
                    smsKeys.add(SmsKey(date, parsed.amount, parsed.isDebit, parsed.ref))
                    if (date < start || date >= end) continue
                    txnIndexOfSms[smsKeys.size - 1] = txns.size
                    if (latestBalance == null && parsed.balance != null) {
                        latestBalance = parsed.balance
                        latestBalanceTime = date
                    }
                    val id = "s$smsId"
                    txns.add(
                        Txn(
                            id = id,
                            time = date,
                            amount = parsed.amount,
                            merchant = parsed.merchant,
                            category = store.categoryFor(id) ?: parsed.category,
                            isDebit = parsed.isDebit,
                            excluded = store.isExcluded(id),
                            body = body,
                            manual = false
                        )
                    )
                }
            } finally {
                cursor.close()
            }
        }
    } catch (e: SecurityException) {
        // Permission was removed while the app was open; show what we have.
    }

    // Lines a few days either side are included so an SMS near the start or end
    // can still find its statement line.
    val bankNear = store.bankAll().filter { it.time >= start - margin && it.time < end + margin }
    val match = matchBankWithSms(bankNear, smsKeys)
    for ((smsIndex, b) in match.pairs) {
        val at = txnIndexOfSms[smsIndex] ?: continue
        // The bank statement has the final amount.
        txns[at] = txns[at].copy(alsoInBank = true, amount = b.amount)
    }
    // An SMS on dates a statement covers, but missing from it, needs checking.
    // A statement can't hold payments made after it was downloaded, so SMS from
    // the last 6 hours before an import are given the benefit of the doubt.
    val bankPeriods = store.bankPeriods()
    if (bankPeriods.isNotEmpty()) {
        for (at in txnIndexOfSms.values) {
            val t = txns[at]
            // Money in and money out alike: the statement is the final word.
            if (t.alsoInBank) continue
            val day = Instant.ofEpochMilli(t.time).atZone(zone).toLocalDate()
            val covered = bankPeriods.any { (a, b, importedAt) ->
                !day.isBefore(a) && !day.isAfter(b) && t.time < importedAt - 6L * 60 * 60 * 1000
            }
            if (!covered) continue
            // Not in the statement means it didn't really happen: never counted.
            txns[at] = t.copy(notInStatement = true, excluded = true)
        }
    }
    val bankTxnIndex = ArrayList<Int>()
    val bankKeys = ArrayList<SmsKey>()
    for (b in match.newLines) {
        if (b.time < start || b.time >= end) continue
        bankKeys.add(SmsKey(b.time, b.amount, b.isDebit, b.ref))
        bankTxnIndex.add(txns.size)
        txns.add(
            Txn(
                id = b.id,
                time = b.time,
                amount = b.amount,
                merchant = b.merchant,
                category = store.categoryFor(b.id) ?: b.category,
                isDebit = b.isDebit,
                excluded = store.isExcluded(b.id),
                body = b.details,
                manual = false,
                fromBank = true
            )
        )
    }

    // Google Pay statement: add only what SMS and bank statements don't already have.
    val gpayNear = store.gpayAll().filter { it.time >= start - margin && it.time < end + margin }
    if (gpayNear.isNotEmpty()) {
        val known = ArrayList<SmsKey>(smsKeys)
        val knownTxnIndex = ArrayList<Int?>()
        for (i in smsKeys.indices) knownTxnIndex.add(txnIndexOfSms[i])
        known.addAll(bankKeys)
        knownTxnIndex.addAll(bankTxnIndex)
        val gm = matchGpay(gpayNear, known)
        for ((k, g) in gm.matched) {
            val at = knownTxnIndex.getOrNull(k) ?: continue
            val t = txns[at]
            // Google Pay has the full payee name; banks often cut it short.
            txns[at] = t.copy(
                alsoInGpay = true,
                merchant = g.name,
                category = store.categoryFor(t.id)
                    ?: (if (t.category == "Other") g.category else t.category)
            )
        }
        for (g in gm.newLines) {
            if (g.time < start || g.time >= end) continue
            txns.add(
                Txn(
                    id = g.id,
                    time = g.time,
                    amount = g.amount,
                    merchant = g.name,
                    category = store.categoryFor(g.id) ?: g.category,
                    isDebit = g.isDebit,
                    excluded = store.isExcluded(g.id),
                    body = if (g.viaLite) "UPI Lite" else "",
                    manual = false,
                    fromGpay = true
                )
            )
        }
    }
    // Top-ups only move money into UPI Lite. Where a Google Pay statement lists
    // the UPI Lite payments themselves, count those instead of the top-up.
    val periods = store.gpayPeriods()
    if (periods.isNotEmpty()) {
        for (i in txns.indices) {
            val t = txns[i]
            if (t.manual || t.fromGpay || t.merchant != "UPI Lite top-up") continue
            val day = Instant.ofEpochMilli(t.time).atZone(zone).toLocalDate()
            if (periods.any { (a, b) -> !day.isBefore(a) && !day.isAfter(b) }) {
                txns[i] = t.copy(excluded = true, liteCovered = true)
            }
        }
    }

    // Label the salary credit with the month it pays for.
    val salaryCache = HashMap<YearMonth, Credit?>()
    val minimum = SalaryFinder.MIN_AMOUNT
    val yesIds = store.salaryHints().yes
    for (i in txns.indices) {
        val t = txns[i]
        if (t.isDebit || t.manual || (t.amount < minimum && t.id !in yesIds)) continue
        val pm = SalaryFinder.payMonthOf(Instant.ofEpochMilli(t.time).atZone(zone).toLocalDate())
        if (!salaryCache.containsKey(pm)) salaryCache[pm] = findSalary(context, store, pm)
        val s = salaryCache[pm] ?: continue
        val same = s.id == t.id ||
            (Math.abs(s.amount - t.amount) < 0.005 && Math.abs(s.time - t.time) <= 36L * 60 * 60 * 1000)
        if (same) txns[i] = t.copy(salaryFor = pm, category = "Salary")
    }

    txns.addAll(store.manualBetween(start, end))
    val remarks = store.allRemarks()
    if (remarks.isNotEmpty()) {
        for (i in txns.indices) {
            val remark = remarks[txns[i].id]
            if (remark != null) txns[i] = txns[i].copy(remark = remark)
        }
    }
    txns.sortByDescending { it.time }
    return MonthData(txns, latestBalance, latestBalanceTime)
}
