package com.spendtrack.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.rememberDateRangePickerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.DateRangePicker
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Switch
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.time.ZoneOffset
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF0B6E4F)
private val GreenSoft = Color(0xFFE3F1EA)
private val Amber = Color(0xFFB26A00)
private val Red = Color(0xFFC62828)
private val Ink = Color(0xFF1B1F1D)
private val Muted = Color(0xFF66706B)
private val Page = Color(0xFFF4F6F2)
private val CardBg = Color(0xFFFFFFFF)
private val Track = Color(0xFFE2E6E1)

class MainActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)
    private val locked = mutableStateOf(false)
    private lateinit var store: Store

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        if (store.reminderSince == 0L) store.reminderSince = System.currentTimeMillis()
        try {
            Reminders.schedule(this)
        } catch (e: Exception) {
            // Reminders are optional; the app works without them.
        }
        locked.value = store.hasPassword()
        applyScreenPrivacy()
        setContent {
            App(
                tick = resumeTick.intValue,
                locked = locked.value,
                onUnlock = { locked.value = false },
                onPasswordChanged = { applyScreenPrivacy() }
            )
        }
    }

    /** Lock again every time the app leaves the screen. */
    override fun onStop() {
        super.onStop()
        if (store.hasPassword()) locked.value = true
    }

    /** With a password set, hide the app from screenshots and the recent-apps preview. */
    private fun applyScreenPrivacy() {
        if (store.hasPassword()) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue = resumeTick.intValue + 1
    }
}

private fun hasSmsPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) ==
        PackageManager.PERMISSION_GRANTED

private fun money(value: Double): String {
    val nf = NumberFormat.getNumberInstance(Locale("en", "IN"))
    nf.maximumFractionDigits = 0
    val sign = if (value < 0) "-" else ""
    return sign + "₹" + nf.format(Math.abs(value))
}

private fun parseAmount(text: String): Double? =
    text.replace(",", "").replace("₹", "").trim().toDoubleOrNull()

@Composable
fun App(tick: Int, locked: Boolean, onUnlock: () -> Unit, onPasswordChanged: () -> Unit) {
    val context = LocalContext.current
    val lockStore = remember { Store(context) }
    var passwordSet by remember { mutableStateOf(lockStore.hasPassword()) }
    var granted by remember { mutableStateOf(hasSmsPermission(context)) }
    LaunchedEffect(tick) { granted = hasSmsPermission(context) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok -> granted = ok }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            background = Page,
            surface = CardBg,
            onSurface = Ink,
            onBackground = Ink
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Page) {
            // The lock screen is drawn over the app rather than replacing it, so
            // work in progress (such as a statement import) is not lost.
            Box(modifier = Modifier.fillMaxSize()) {
                if (granted) {
                    Home(tick, onPasswordChanged)
                } else {
                    PermissionScreen(onAllow = { launcher.launch(Manifest.permission.READ_SMS) })
                }
                if (!passwordSet) {
                    // First run: the app cannot be used until a password exists.
                    SetupPasswordScreen(
                        store = lockStore,
                        onDone = {
                            passwordSet = true
                            onPasswordChanged()
                        }
                    )
                } else if (locked) {
                    LockScreen(store = lockStore, onUnlock = onUnlock)
                }
            }
        }
    }
}

@Composable
private fun PermissionScreen(onAllow: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("SpendTrack", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Green)
        Spacer(Modifier.height(16.dp))
        Text(
            "To add up your spending, the app reads the payment alerts your bank sends by SMS.",
            textAlign = TextAlign.Center,
            color = Ink,
            fontSize = 16.sp
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Your messages never leave this phone. The app has no internet access.",
            textAlign = TextAlign.Center,
            color = Muted,
            fontSize = 14.sp
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onAllow) { Text("Allow SMS access") }
        Spacer(Modifier.height(18.dp))
        Text(
            "If the button does nothing: open phone Settings > Apps > SpendTrack. " +
                "Tap the three dots and choose \"Allow restricted settings\" if you see it, " +
                "then Permissions > SMS > Allow.",
            textAlign = TextAlign.Center,
            color = Muted,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun LockScreen(store: Store, onUnlock: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {},
        color = Page
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("SpendTrack", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Green)
            Spacer(Modifier.height(8.dp))
            Text("Enter your password to open the app.", color = Ink, fontSize = 15.sp)
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = input,
                onValueChange = {
                    input = it
                    error = null
                },
                label = { Text("Password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            val err = error
            if (err != null) {
                Spacer(Modifier.height(8.dp))
                Text(err, color = Red, fontSize = 14.sp)
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    val wait = store.lockWaitSeconds()
                    if (wait > 0) {
                        error = "Too many wrong tries. Wait " + wait + " seconds."
                    } else if (store.tryUnlock(input)) {
                        input = ""
                        error = null
                        onUnlock()
                    } else {
                        input = ""
                        val now = store.lockWaitSeconds()
                        error = if (now > 0) "Too many wrong tries. Wait " + now + " seconds."
                        else "Wrong password."
                    }
                },
                enabled = input.isNotEmpty()
            ) { Text("Unlock") }
            Spacer(Modifier.height(24.dp))
            Text(
                "Forgot it? The only way back in is phone Settings > Apps > SpendTrack > " +
                    "Storage > Clear data. That erases your budget, categories, remarks, " +
                    "added entries and imported statements.",
                textAlign = TextAlign.Center,
                color = Muted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun SetupPasswordScreen(store: Store, onDone: () -> Unit) {
    var fresh by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {},
        color = Page
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("SpendTrack", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Green)
            Spacer(Modifier.height(8.dp))
            Text(
                "Create a password. You will need it every time you open the app.",
                textAlign = TextAlign.Center,
                color = Ink,
                fontSize = 15.sp
            )
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = fresh,
                onValueChange = {
                    fresh = it
                    error = null
                },
                label = { Text("Password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = again,
                onValueChange = {
                    again = it
                    error = null
                },
                label = { Text("Password again") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            val err = error
            if (err != null) {
                Spacer(Modifier.height(8.dp))
                Text(err, color = Red, fontSize = 14.sp)
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    if (fresh.length < 4) {
                        error = "Use at least 4 characters."
                    } else if (fresh != again) {
                        error = "The two passwords don't match."
                    } else {
                        store.setPassword(fresh)
                        onDone()
                    }
                }
            ) { Text("Create password") }
            Spacer(Modifier.height(24.dp))
            Text(
                "A forgotten password cannot be recovered. The only reset is phone " +
                    "Settings > Apps > SpendTrack > Storage > Clear data, which erases " +
                    "your budget, categories, remarks and imported statements.",
                textAlign = TextAlign.Center,
                color = Muted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun PasswordDialog(
    store: Store,
    hasPassword: Boolean,
    onDismiss: () -> Unit,
    onChanged: () -> Unit
) {
    var current by remember { mutableStateOf("") }
    var fresh by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (hasPassword) "Change password" else "Set a password") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "The app will ask for this every time it is opened. There is no way " +
                        "to recover a forgotten password, so pick one you will remember.",
                    color = Muted,
                    fontSize = 13.sp
                )
                if (hasPassword) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = current,
                        onValueChange = {
                            current = it
                            error = null
                        },
                        label = { Text("Current password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                    )
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = fresh,
                    onValueChange = {
                        fresh = it
                        error = null
                    },
                    label = { Text("New password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = again,
                    onValueChange = {
                        again = it
                        error = null
                    },
                    label = { Text("New password again") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                val err = error
                if (err != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(err, color = Red, fontSize = 13.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (hasPassword && !store.passwordMatches(current)) {
                    error = "Current password is wrong."
                } else if (fresh.length < 4) {
                    error = "Use at least 4 characters."
                } else if (fresh != again) {
                    error = "The two new passwords don't match."
                } else {
                    store.setPassword(fresh)
                    onChanged()
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun Home(tick: Int, onPasswordChanged: () -> Unit) {
    val context = LocalContext.current
    val store = remember { Store(context) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var version by remember { mutableIntStateOf(0) }
    var data by remember { mutableStateOf<MonthData?>(null) }
    var budget by remember { mutableStateOf(store.budget) }

    var showBudget by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Txn?>(null) }
    var showImport by remember { mutableStateOf(false) }
    var importMessage by remember { mutableStateOf<String?>(null) }
    var importedCount by remember { mutableIntStateOf(0) }
    var filter by remember { mutableStateOf("All") }
    var catFilter by remember { mutableStateOf<String?>(null) }
    // Date filter: null = the whole month shown at the top.
    var dateRange by remember { mutableStateOf<Pair<LocalDate, LocalDate>?>(null) }
    var rangeData by remember { mutableStateOf<MonthData?>(null) }
    var showDates by remember { mutableStateOf(false) }
    val hasPassword = true
    var showPassword by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    // A locked file waiting for its password.
    var pwUri by remember { mutableStateOf<Uri?>(null) }
    var pwMessage by remember { mutableStateOf("") }
    var remindOn by remember { mutableStateOf(store.remindersOn) }
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    fun askForNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !Reminders.canNotify(context)) {
            store.notificationAsked = true
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    fun runImport(uri: Uri, password: String?, rememberIt: Boolean) {
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                importStatement(context, store, uri, password, rememberIt)
            }
            if (result.needsPassword) {
                pwUri = uri
                pwMessage = result.message
            } else {
                pwUri = null
                val latest = result.latestMonth
                if (latest != null) {
                    month = if (latest.isAfter(YearMonth.now())) YearMonth.now() else latest
                }
                importMessage = result.message
                version = version + 1
            }
        }
    }
    fun openImport() {
        scope.launch {
            importedCount = withContext(Dispatchers.IO) { store.bankCount() }
            showImport = true
            if (store.remindersOn && !store.notificationAsked) askForNotifications()
        }
    }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) runImport(uri, null, false)
    }

    LaunchedEffect(month, version, tick) {
        val m = month
        data = withContext(Dispatchers.IO) { loadMonth(context, store, m) }
    }
    LaunchedEffect(dateRange, version, tick) {
        val r = dateRange
        if (r == null) {
            rangeData = null
        } else {
            rangeData = null
            rangeData = withContext(Dispatchers.IO) { loadDays(context, store, r.first, r.second) }
        }
    }

    val current = data
    val orderedCategories = remember(version) { store.allCategories() }
    val statementBalance = remember(version) { store.statementBalance() }
    val spent = current?.spent ?: 0.0
    val left = budget - spent
    val today = LocalDate.now()
    val isThisMonth = month == YearMonth.now()
    val daysLeft = if (isThisMonth) month.lengthOfMonth() - today.dayOfMonth + 1 else 0

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "top") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "SpendTrack",
                        color = Green,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "Change password",
                        color = Green,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showPassword = true }
                            .padding(horizontal = 8.dp, vertical = 10.dp)
                    )
                }
            }
            item(key = "header") {
                MonthHeader(
                    month = month,
                    canGoForward = !isThisMonth,
                    onBack = { month = month.minusMonths(1) },
                    onForward = { month = month.plusMonths(1) }
                )
            }
            val toCheck = current?.txns?.count { it.notInStatement && !it.reviewed } ?: 0
            if (toCheck > 0) {
                item(key = "tocheck") {
                    Card {
                        Text(
                            if (toCheck == 1) "1 SMS payment isn't in your bank statement"
                            else "$toCheck SMS payments aren't in your bank statement",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Amber
                        )
                        Text(
                            "The statement is the final word, so they're left out of your " +
                                "totals until you check them.",
                            color = Muted,
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = {
                            filter = "To check"
                            catFilter = null
                            dateRange = null
                        }) { Text("Review") }
                    }
                }
            }
            if (Reminders.isDue(store)) {
                item(key = "reminder") {
                    val days = Reminders.daysSinceImport(store)
                    Card {
                        Text("Time to import your statement", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
                        Text(
                            if (days == null) "You haven't imported a bank statement yet."
                            else "Your last import was $days days ago.",
                            color = Muted,
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { openImport() }) { Text("Import now") }
                    }
                }
            }
            item(key = "budget") {
                BudgetCard(
                    budget = budget,
                    spent = spent,
                    left = left,
                    daysLeft = daysLeft,
                    balances = if (!isThisMonth) emptyList() else listOfNotNull(
                        current?.latestBalance?.let { b ->
                            Triple("SMS", b, current?.latestBalanceTime ?: System.currentTimeMillis())
                        },
                        statementBalance?.let { Triple("statement", it.first, it.second) }
                    ),
                    received = current?.received ?: 0.0,
                    onEdit = { showBudget = true }
                )
            }
            if (isThisMonth) {
                item(key = "afford") {
                    AffordCard(budget = budget, left = left, daysLeft = daysLeft)
                }
            }
            val cats = current?.byCategory ?: emptyList()
            if (cats.isNotEmpty()) {
                item(key = "cats") {
                    CategoryCard(
                        cats = cats,
                        total = spent,
                        selected = catFilter,
                        onPick = { cat -> catFilter = if (catFilter == cat) null else cat }
                    )
                }
            }
            item(key = "title") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Transactions",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Ink,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "Import statement",
                        color = Green,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { openImport() }
                            .padding(horizontal = 8.dp, vertical = 10.dp)
                    )
                }
            }
            val dr = dateRange
            // With a date filter on, the list comes from those days (any month).
            val listTxns = if (dr != null) rangeData?.txns else current?.txns
            val cf = catFilter
            val shown = (listTxns ?: emptyList()).filter {
                matchesFilter(it, filter) && (cf == null || (it.isDebit && it.category == cf))
            }
            // Category chips: the categories used this month, in the user's order.
            val used = (listTxns ?: emptyList()).filter { it.isDebit }.map { it.category }.toSet()
            val ordered = orderedCategories
            val catChips = ordered.filter { it in used } +
                used.filter { it !in ordered }.sorted() +
                (if (cf != null && cf !in used) listOf(cf) else emptyList())
            item(key = "filters") {
                Column {
                    DateChips(
                        range = dr,
                        onPick = { dateRange = it },
                        onCustom = { showDates = true }
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (name in FILTERS) {
                            Chip(label = name, selected = name == filter, onClick = { filter = name })
                        }
                    }
                    if (catChips.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Chip(
                                label = "All categories",
                                selected = cf == null,
                                onClick = { catFilter = null }
                            )
                            for (cat in catChips) {
                                Chip(label = cat, selected = cat == cf, onClick = { catFilter = cat })
                            }
                        }
                    }
                    if ((filter != "All" || cf != null || dr != null) && listTxns != null) {
                        val total = shown.filter { it.isDebit && !it.excluded }.sumOf { it.amount }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            shown.size.toString() + (if (shown.size == 1) " entry" else " entries") +
                                " · " + money(total) + " spent",
                            color = Muted,
                            fontSize = 13.sp
                        )
                    }
                }
            }
            if (listTxns == null) {
                item(key = "loading") { Text("Reading your messages…", color = Muted) }
            } else if (shown.isEmpty() && listTxns.isNotEmpty()) {
                item(key = "nomatch") {
                    Text("Nothing matches these filters.", color = Muted)
                }
            } else if (listTxns.isEmpty() && dr != null) {
                item(key = "nodays") {
                    Text("No payments on these dates.", color = Muted)
                }
            } else if (listTxns.isEmpty()) {
                item(key = "empty") {
                    Text(
                        "No payment messages found for this month. " +
                            "Tap + to add a cash expense yourself.",
                        color = Muted
                    )
                }
            } else {
                items(shown, key = { it.id }) { txn ->
                    TxnRow(txn = txn, onClick = { selected = txn })
                }
            }
        }

        FloatingActionButton(
            onClick = { showAdd = true },
            containerColor = Green,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) {
            Text("+", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }

    if (showBudget) {
        BudgetDialog(
            initial = budget,
            onDismiss = { showBudget = false },
            onSave = { value ->
                store.budget = value
                budget = value
                showBudget = false
            }
        )
    }
    if (showAdd) {
        AddExpenseDialog(
            onDismiss = { showAdd = false },
            onSave = { amount, note, category, day ->
                // Today keeps the current time; another day is filed at midday.
                val time = if (day == LocalDate.now()) System.currentTimeMillis()
                else day.atTime(12, 0).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
                store.addManual(amount, note, category, time)
                showAdd = false
                month = YearMonth.from(day)
                version = version + 1
            }
        )
    }
    if (showDates) {
        DateRangeDialog(
            initial = dateRange,
            onDismiss = { showDates = false },
            onPick = { a, b ->
                dateRange = a to b
                showDates = false
            }
        )
    }
    if (showPassword) {
        PasswordDialog(
            store = store,
            hasPassword = hasPassword,
            onDismiss = { showPassword = false },
            onChanged = {
                showPassword = false
                onPasswordChanged()
            }
        )
    }
    if (showImport) {
        AlertDialog(
            onDismissRequest = { showImport = false },
            title = { Text("Import statement") },
            text = {
                Column {
                    Text(
                        "Choose a bank statement saved as Excel (.xlsx) or CSV, or a " +
                            "Google Pay transaction statement (PDF). Payments the app " +
                            "already has are not counted twice.",
                        color = Ink,
                        fontSize = 14.sp
                    )
                    if (importedCount > 0) {
                        Spacer(Modifier.height(12.dp))
                        Text(
                            importedCount.toString() + " statement lines are stored on this phone.",
                            color = Muted,
                            fontSize = 13.sp
                        )
                        TextButton(onClick = {
                            store.clearBank()
                            showImport = false
                            version = version + 1
                        }) { Text("Remove imported statements", color = Red) }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Remind me every 7 days", color = Ink, fontSize = 14.sp)
                            val days = Reminders.daysSinceImport(store)
                            Text(
                                if (days == null) "No statement imported yet"
                                else if (days == 0) "Last import: today"
                                else "Last import: $days " + (if (days == 1) "day" else "days") + " ago",
                                color = Muted,
                                fontSize = 12.sp
                            )
                        }
                        Switch(checked = remindOn, onCheckedChange = { on ->
                            remindOn = on
                            store.remindersOn = on
                            if (on && store.reminderSince == 0L) store.reminderSince = System.currentTimeMillis()
                            try {
                                Reminders.schedule(context)
                            } catch (e: Exception) {
                                // optional feature
                            }
                            if (on) askForNotifications()
                        })
                    }
                    if (store.statementPassword != null) {
                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "A statement password is saved",
                                color = Muted,
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                store.statementPassword = null
                                showImport = false
                            }) { Text("Forget it", color = Red) }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showImport = false
                    picker.launch(arrayOf("*/*"))
                }) { Text("Choose file") }
            },
            dismissButton = { TextButton(onClick = { showImport = false }) { Text("Cancel") } }
        )
    }
    val lockedUri = pwUri
    if (lockedUri != null) {
        FilePasswordDialog(
            message = pwMessage,
            onDismiss = { pwUri = null },
            onSubmit = { pw, rememberIt -> runImport(lockedUri, pw, rememberIt) }
        )
    }
    val message = importMessage
    if (message != null) {
        AlertDialog(
            onDismissRequest = { importMessage = null },
            title = { Text("Statement import") },
            text = { Text(message, color = Ink, fontSize = 14.sp) },
            confirmButton = { TextButton(onClick = { importMessage = null }) { Text("OK") } }
        )
    }
    val sel = selected
    if (sel != null) {
        TxnDialog(
            txn = sel,
            onDismiss = { selected = null },
            onSave = { category, remark ->
                if (!sel.manual && sel.isDebit && category != sel.category) {
                    store.setCategory(sel.id, category)
                }
                store.setRemark(sel.id, remark)
                selected = null
                version = version + 1
            },
            onReview = { count, category, remark ->
                if (sel.isDebit && category != sel.category) store.setCategory(sel.id, category)
                store.setRemark(sel.id, remark)
                store.setReview(sel.id, if (count) "count" else "skip")
                if (count) store.setExcluded(sel.id, false)
                selected = null
                version = version + 1
            },
            onToggleExcluded = { remark ->
                if (sel.manual) {
                    store.setRemark(sel.id, "")
                    store.deleteManual(sel.id)
                } else {
                    store.setRemark(sel.id, remark)
                    store.setExcluded(sel.id, !sel.excluded)
                }
                selected = null
                version = version + 1
            }
        )
    }
}

@Composable
private fun FilePasswordDialog(
    message: String,
    onDismiss: () -> Unit,
    onSubmit: (String, Boolean) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var rememberIt by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Statement password") },
        text = {
            Column {
                Text(message, color = Ink, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("File password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = rememberIt, onCheckedChange = { rememberIt = it })
                    Text("Remember for next time", color = Ink, fontSize = 14.sp)
                }
                Text(
                    "Banks usually use the same password every time. It is kept only " +
                        "on this phone, inside the locked app.",
                    color = Muted,
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSubmit(input, rememberIt) },
                enabled = input.isNotEmpty()
            ) { Text("Open") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Quick date choices plus a calendar for any range. */
@Composable
private fun DateChips(
    range: Pair<LocalDate, LocalDate>?,
    onPick: (Pair<LocalDate, LocalDate>?) -> Unit,
    onCustom: () -> Unit
) {
    val today = LocalDate.now()
    val presets = listOf(
        "Today" to (today to today),
        "Yesterday" to (today.minusDays(1) to today.minusDays(1)),
        "Last 7 days" to (today.minusDays(6) to today)
    )
    val isPreset = range == null || presets.any { it.second == range }
    val fmt = DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH)
    val customLabel = if (range != null && !isPreset) {
        if (range.first == range.second) range.first.format(fmt)
        else range.first.format(fmt) + " – " + range.second.format(fmt)
    } else "Pick dates"
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Chip(label = "Whole month", selected = range == null, onClick = { onPick(null) })
        for ((label, r) in presets) {
            Chip(label = label, selected = range == r, onClick = { onPick(r) })
        }
        Chip(label = customLabel, selected = !isPreset, onClick = onCustom)
    }
}

private fun utcMillis(d: LocalDate): Long = d.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
private fun utcDate(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DateRangeDialog(
    initial: Pair<LocalDate, LocalDate>?,
    onDismiss: () -> Unit,
    onPick: (LocalDate, LocalDate) -> Unit
) {
    val state = rememberDateRangePickerState(
        initialSelectedStartDateMillis = initial?.first?.let { utcMillis(it) },
        initialSelectedEndDateMillis = initial?.second?.let { utcMillis(it) }
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    val s = state.selectedStartDateMillis
                    if (s != null) {
                        val a = utcDate(s)
                        val e = state.selectedEndDateMillis
                        val b = if (e != null) utcDate(e) else a
                        if (b.isBefore(a)) onPick(b, a) else onPick(a, b)
                    }
                },
                enabled = state.selectedStartDateMillis != null
            ) { Text("Apply") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    ) {
        DateRangePicker(
            state = state,
            modifier = Modifier.weight(1f),
            title = {
                Text(
                    "Pick a start and an end date",
                    modifier = Modifier.padding(start = 24.dp, end = 12.dp, top = 16.dp)
                )
            }
        )
    }
}

private val FILTERS = listOf("All", "To check", "SMS", "Statement", "Google Pay", "In both", "Added by you")

private fun matchesFilter(txn: Txn, filter: String): Boolean = when (filter) {
    // Every payment that has an SMS, whether or not a statement also lists it.
    "SMS" -> !txn.manual && !txn.fromBank && !txn.fromGpay
    // Every payment a statement lists, whether or not it also had an SMS.
    "Statement" -> txn.fromBank || txn.alsoInBank
    "To check" -> txn.notInStatement
    "Google Pay" -> txn.fromGpay || txn.alsoInGpay
    "In both" -> txn.alsoInBank
    "Added by you" -> txn.manual
    else -> true
}

@Composable
private fun Card(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBg)
            .padding(18.dp)
    ) {
        content()
    }
}

@Composable
private fun MonthHeader(
    month: YearMonth,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "‹",
            fontSize = 32.sp,
            color = Green,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { onBack() }
                .padding(horizontal = 16.dp, vertical = 2.dp)
        )
        Text(
            month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Ink,
            textAlign = TextAlign.Center,
            modifier = Modifier.weight(1f)
        )
        Text(
            "›",
            fontSize = 32.sp,
            color = if (canGoForward) Green else Track,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable(enabled = canGoForward) { onForward() }
                .padding(horizontal = 16.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun Bar(fraction: Float, color: Color) {
    val f = if (fraction.isNaN()) 0f else fraction.coerceIn(0f, 1f)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(RoundedCornerShape(5.dp))
            .background(Track)
    ) {
        if (f > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(color)
            )
        }
    }
}

@Composable
private fun BudgetCard(
    budget: Double,
    spent: Double,
    left: Double,
    daysLeft: Int,
    /** (source, amount, when) for each balance known: from SMS and from a statement. */
    balances: List<Triple<String, Double, Long>>,
    received: Double,
    onEdit: () -> Unit
) {
    Card {
        if (budget <= 0.0) {
            Text("Spent this month", color = Muted, fontSize = 14.sp)
            Text(money(spent), fontSize = 38.sp, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onEdit) { Text("Set a monthly budget") }
        } else {
            val used = (spent / budget).toFloat()
            val color = if (left < 0) Red else if (used > 0.8f) Amber else Green
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (left < 0) "Over budget by" else "Left to spend",
                    color = Muted,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "Edit budget",
                    color = Green,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onEdit() }
                        .padding(6.dp)
                )
            }
            Text(
                money(Math.abs(left)),
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Spacer(Modifier.height(10.dp))
            Bar(fraction = used, color = color)
            Spacer(Modifier.height(8.dp))
            Text(
                "Spent " + money(spent) + " of " + money(budget),
                color = Ink,
                fontSize = 14.sp
            )
            if (daysLeft > 0 && left > 0) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "About " + money(left / daysLeft) + " a day for the next " +
                        daysLeft + (if (daysLeft == 1) " day" else " days"),
                    color = Muted,
                    fontSize = 14.sp
                )
            }
        }
        if (balances.isNotEmpty() || received > 0.0) {
            Spacer(Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Track)
            )
            Spacer(Modifier.height(10.dp))
            if (balances.isNotEmpty()) {
                // Show the lower one, so the figure errs on the safe side.
                val low = balances.minByOrNull { it.second }!!
                val fmt = SimpleDateFormat("d MMM", Locale.ENGLISH)
                Text(
                    "Bank balance: " + money(low.second),
                    color = Ink,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    if (balances.size > 1)
                        "Lower of SMS " + money(balances[0].second) + " (" + fmt.format(Date(balances[0].third)) +
                            ") and statement " + money(balances[1].second) + " (" + fmt.format(Date(balances[1].third)) + ")"
                    else
                        "From the " + low.first + " of " + fmt.format(Date(low.third)),
                    color = Muted,
                    fontSize = 12.sp
                )
            }
            if (received > 0.0) {
                Text(
                    "Money received this month: " + money(received),
                    color = Muted,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun AffordCard(budget: Double, left: Double, daysLeft: Int) {
    var input by remember { mutableStateOf("") }
    Card {
        Text("Can I buy this?", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Price in ₹") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        val price = parseAmount(input)
        if (price != null && price > 0.0) {
            Spacer(Modifier.height(10.dp))
            if (budget <= 0.0) {
                Text("Set a monthly budget first, then I can answer.", color = Muted)
            } else {
                val after = left - price
                val verdict: String
                val detail: String
                val color: Color
                if (after < 0) {
                    color = Red
                    verdict = "Not within budget"
                    detail = if (left <= 0)
                        "You are already over this month's budget."
                    else
                        "It costs " + money(price - left) + " more than the " +
                            money(left) + " you have left."
                } else {
                    val share = if (left > 0) price / left else 1.0
                    val perDay = if (daysLeft > 0) after / daysLeft else after
                    if (share > 0.5) {
                        color = Amber
                        verdict = "Possible, but it's a big bite"
                    } else {
                        color = Green
                        verdict = "Yes, it fits"
                    }
                    detail = "You'd have " + money(after) + " left, about " + money(perDay) +
                        " a day for " + daysLeft + (if (daysLeft == 1) " day." else " days.")
                }
                Text(verdict, color = color, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(detail, color = Ink, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun CategoryCard(
    cats: List<Pair<String, Double>>,
    total: Double,
    selected: String?,
    onPick: (String) -> Unit
) {
    Card {
        Text("Where it went", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
        Text("Tap a category to see its payments.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        for (entry in cats) {
            val on = entry.first == selected
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (on) GreenSoft else CardBg)
                    .clickable { onPick(entry.first) }
                    .padding(horizontal = 6.dp, vertical = 6.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        entry.first,
                        color = Ink,
                        fontSize = 14.sp,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f)
                    )
                    Text(money(entry.second), color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.height(4.dp))
                Bar(fraction = if (total > 0) (entry.second / total).toFloat() else 0f, color = Green)
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun TxnRow(txn: Txn, onClick: () -> Unit) {
    val time = remember(txn.time, txn.fromBank) {
        SimpleDateFormat(if (txn.fromBank) "d MMM" else "d MMM, h:mm a", Locale.ENGLISH)
            .format(Date(txn.time))
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CardBg)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                txn.merchant,
                color = if (txn.excluded) Muted else Ink,
                fontWeight = FontWeight.Medium,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val sources = listOfNotNull(
                if (!txn.manual && !txn.fromBank && !txn.fromGpay) "SMS" else null,
                if (txn.fromBank || txn.alsoInBank) "statement" else null,
                if (txn.fromGpay || txn.alsoInGpay) (if (txn.body == "UPI Lite") "GPay UPI Lite" else "Google Pay") else null
            )
            val sub = when {
                txn.notInStatement && !txn.reviewed -> "Not in bank statement · tap to check"
                txn.notInStatement && txn.excluded -> "Not in statement · not counted"
                txn.notInStatement -> txn.category + " · not in statement, counted"
                txn.liteCovered -> "Top-up · counted via Google Pay"
                txn.excluded -> "Not counted"
                !txn.isDebit -> "Received"
                txn.manual -> txn.category + " · added by you"
                else -> txn.category + " · " + sources.joinToString(" + ")
            }
            Text(
                time + " · " + sub,
                color = if (txn.notInStatement && !txn.reviewed) Amber else Muted,
                fontSize = 12.sp,
                fontWeight = if (txn.notInStatement && !txn.reviewed) FontWeight.Medium else FontWeight.Normal
            )
            if (txn.remark.isNotBlank()) {
                Text(
                    txn.remark,
                    color = Ink,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(
            (if (txn.isDebit) "" else "+") + money(txn.amount),
            color = if (txn.excluded) Muted else if (txn.isDebit) Ink else Green,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) Color.White else Ink,
        fontSize = 14.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Green else GreenSoft)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CategoryChips(selected: String, onSelect: (String) -> Unit) {
    val context = LocalContext.current
    val store = remember { Store(context) }
    var categories by remember { mutableStateOf(store.allCategories()) }
    var showNew by remember { mutableStateOf(false) }
    // A payment filed under a category that was later removed still shows it.
    val shown = if (selected.isNotEmpty() && selected !in categories) categories + selected else categories
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (cat in shown) {
            Chip(label = cat, selected = cat == selected, onClick = { onSelect(cat) })
        }
        Chip(label = "+ New / reorder", selected = false, onClick = { showNew = true })
    }
    if (showNew) {
        NewCategoryDialog(
            store = store,
            onDismiss = {
                categories = store.allCategories()
                showNew = false
            },
            onAdded = { name ->
                categories = store.allCategories()
                showNew = false
                onSelect(name)
            },
            onRemoved = { categories = store.allCategories() }
        )
    }
}

@Composable
private fun NewCategoryDialog(
    store: Store,
    onDismiss: () -> Unit,
    onAdded: (String) -> Unit,
    onRemoved: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var mine by remember { mutableStateOf(store.customCategories()) }
    var all by remember { mutableStateOf(store.allCategories()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Categories") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        error = null
                    },
                    label = { Text("New category name") },
                    placeholder = { Text("e.g. Rent, Gym, Gifts") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                val err = error
                if (err != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(err, color = Red, fontSize = 13.sp)
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    "Order shown when picking a category. Use the arrows to move one.",
                    color = Muted,
                    fontSize = 13.sp
                )
                for ((index, cat) in all.withIndex()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            cat,
                            color = Ink,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = {
                                store.moveCategory(cat, -1)
                                all = store.allCategories()
                                onRemoved()
                            },
                            enabled = index > 0
                        ) { Text("↑", fontSize = 18.sp) }
                        TextButton(
                            onClick = {
                                store.moveCategory(cat, 1)
                                all = store.allCategories()
                                onRemoved()
                            },
                            enabled = index < all.size - 1
                        ) { Text("↓", fontSize = 18.sp) }
                        if (cat in mine) {
                            TextButton(onClick = {
                                store.removeCategory(cat)
                                mine = store.customCategories()
                                all = store.allCategories()
                                onRemoved()
                            }) { Text("Remove", color = Red) }
                        }
                    }
                }
                if (mine.isNotEmpty()) {
                    Text(
                        "Removing a category keeps it on payments already filed under it.",
                        color = Muted,
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val problem = store.addCategory(name)
                if (problem != null) {
                    error = problem
                } else {
                    onAdded(cleanCategoryName(name))
                }
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun BudgetDialog(initial: Double, onDismiss: () -> Unit, onSave: (Double) -> Unit) {
    var input by remember {
        mutableStateOf(if (initial > 0) initial.toLong().toString() else "")
    }
    val value = parseAmount(input)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Monthly budget") },
        text = {
            Column {
                Text("How much do you want to spend in a month?", color = Muted, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("Amount in ₹") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (value != null) onSave(value) },
                enabled = value != null && value >= 0.0
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun AddExpenseDialog(
    onDismiss: () -> Unit,
    onSave: (Double, String, String, LocalDate) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Cash") }
    var day by remember { mutableStateOf(LocalDate.now()) }
    var pickDay by remember { mutableStateOf(false) }
    val value = parseAmount(amount)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add an expense") },
        text = {
            Column {
                Text(
                    "For cash or anything that didn't send an SMS.",
                    color = Muted,
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Amount in ₹") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("What was it for?") },
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Date", color = Muted, fontSize = 14.sp, modifier = Modifier.width(48.dp))
                    val today = LocalDate.now()
                    val label = when (day) {
                        today -> "Today"
                        today.minusDays(1) -> "Yesterday"
                        else -> day.format(DateTimeFormatter.ofPattern("EEE d MMM yyyy", Locale.ENGLISH))
                    }
                    Chip(label = "$label  ▾", selected = false, onClick = { pickDay = true })
                }
                Spacer(Modifier.height(12.dp))
                CategoryChips(selected = category, onSelect = { category = it })
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (value != null) onSave(value, note.trim(), category, day) },
                enabled = value != null && value > 0.0
            ) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
    if (pickDay) {
        DayDialog(
            initial = day,
            onDismiss = { pickDay = false },
            onPick = {
                day = it
                pickDay = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DayDialog(initial: LocalDate, onDismiss: () -> Unit, onPick: (LocalDate) -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = utcMillis(initial))
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    val ms = state.selectedDateMillis
                    if (ms != null) onPick(utcDate(ms))
                },
                enabled = state.selectedDateMillis != null
            ) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    ) {
        DatePicker(state = state)
    }
}

@Composable
private fun TxnDialog(
    txn: Txn,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit,
    onToggleExcluded: (String) -> Unit,
    onReview: (Boolean, String, String) -> Unit
) {
    var category by remember(txn.id) { mutableStateOf(txn.category) }
    var remark by remember(txn.id) { mutableStateOf(txn.remark) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(txn.merchant, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    (if (txn.isDebit) "" else "+") + money(txn.amount),
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (txn.isDebit) Ink else Green
                )
                Text(
                    SimpleDateFormat(
                        if (txn.fromBank) "EEE d MMM yyyy" else "EEE d MMM yyyy, h:mm a",
                        Locale.ENGLISH
                    ).format(Date(txn.time)),
                    color = Muted,
                    fontSize = 13.sp
                )
                if (txn.isDebit && !txn.manual) {
                    Spacer(Modifier.height(14.dp))
                    Text("Category", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    CategoryChips(selected = category, onSelect = { category = it })
                }
                if (txn.notInStatement) {
                    Spacer(Modifier.height(14.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFFFF3E0))
                            .padding(12.dp)
                    ) {
                        Text("Not in your bank statement", color = Amber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "This SMS is dated within your imported statement, but the statement " +
                                "has no matching debit. It may have failed, been reversed, or come " +
                                "from a different account.",
                            color = Ink,
                            fontSize = 13.sp
                        )
                        Text(
                            when {
                                !txn.reviewed -> "Not counted until you decide."
                                txn.excluded -> "You chose not to count it."
                                else -> "You chose to count it."
                            },
                            color = Muted,
                            fontSize = 12.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { onReview(true, category, remark) }) { Text("Count it") }
                            TextButton(onClick = { onReview(false, category, remark) }) {
                                Text("Don't count", color = Red)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = remark,
                    onValueChange = { remark = it },
                    label = { Text("Remarks") },
                    placeholder = { Text("What was this for?") },
                    minLines = 2,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(category, remark) }) { Text("Save") }
        },
        dismissButton = if (txn.liteCovered || txn.notInStatement) null else ({
            TextButton(onClick = { onToggleExcluded(remark) }) {
                Text(
                    when {
                        txn.manual -> "Delete"
                        txn.excluded -> "Count it again"
                        else -> "Don't count this"
                    },
                    color = if (txn.manual || !txn.excluded) Red else Green
                )
            }
        })
    )
}
