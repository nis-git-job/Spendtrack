package com.spendtrack.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF0B6E4F)
private val GreenSoft = Color(0xFFE3F1EA)
private val Amber = Color(0xFFB26A00)
private val Red = Color(0xFFC62828)
private val Ink = Color(0xFF1B1F1D)
private val Muted = Color(0xFF66706B)
private val Page = Color(0xFFF4F6F2)
private val CardBg = Color(0xFFFFFFFF)
private val Track = Color(0xFFE2E6E1)

class MainActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(resumeTick.intValue) }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue = resumeTick.intValue + 1
    }
}

private fun hasSmsPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) ==
        PackageManager.PERMISSION_GRANTED

private fun money(value: Double): String {
    val nf = NumberFormat.getNumberInstance(Locale("en", "IN"))
    nf.maximumFractionDigits = 0
    val sign = if (value < 0) "-" else ""
    return sign + "₹" + nf.format(Math.abs(value))
}

private fun parseAmount(text: String): Double? =
    text.replace(",", "").replace("₹", "").trim().toDoubleOrNull()

@Composable
fun App(tick: Int) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasSmsPermission(context)) }
    LaunchedEffect(tick) { granted = hasSmsPermission(context) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok -> granted = ok }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            background = Page,
            surface = CardBg,
            onSurface = Ink,
            onBackground = Ink
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Page) {
            if (granted) {
                Home(tick)
            } else {
                PermissionScreen(onAllow = { launcher.launch(Manifest.permission.READ_SMS) })
            }
        }
    }
}

@Composable
private fun PermissionScreen(onAllow: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("SpendTrack", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Green)
        Spacer(Modifier.height(16.dp))
        Text(
            "To add up your spending, the app reads the payment alerts your bank sends by SMS.",
            textAlign = TextAlign.Center,
            color = Ink,
            fontSize = 16.sp
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Your messages never leave this phone. The app has no internet access.",
            textAlign = TextAlign.Center,
            color = Muted,
            fontSize = 14.sp
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onAllow) { Text("Allow SMS access") }
        Spacer(Modifier.height(18.dp))
        Text(
            "If the button does nothing: open phone Settings > Apps > SpendTrack. " +
                "Tap the three dots and choose \"Allow restricted settings\" if you see it, " +
                "then Permissions > SMS > Allow.",
            textAlign = TextAlign.Center,
            color = Muted,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun Home(tick: Int) {
    val context = LocalContext.current
    val store = remember { Store(context) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var version by remember { mutableIntStateOf(0) }
    var data by remember { mutableStateOf<MonthData?>(null) }
    var budget by remember { mutableStateOf(store.budget) }

    var showBudget by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Txn?>(null) }

    LaunchedEffect(month, version, tick) {
        val m = month
        data = withContext(Dispatchers.IO) { loadMonth(context, store, m) }
    }

    val current = data
    val spent = current?.spent ?: 0.0
    val left = budget - spent
    val today = LocalDate.now()
    val isThisMonth = month == YearMonth.now()
    val daysLeft = if (isThisMonth) month.lengthOfMonth() - today.dayOfMonth + 1 else 0

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "header") {
                MonthHeader(
                    month = month,
                    canGoForward = !isThisMonth,
                    onBack = { month = month.minusMonths(1) },
                    onForward = { month = month.plusMonths(1) }
                )
            }
            item(key = "budget") {
                BudgetCard(
                    budget = budget,
                    spent = spent,
                    left = left,
                    daysLeft = daysLeft,
                    balance = if (isThisMonth) current?.latestBalance else null,
                    received = current?.received ?: 0.0,
                    onEdit = { showBudget = true }
                )
            }
            if (isThisMonth) {
                item(key = "afford") {
                    AffordCard(budget = budget, left = left, daysLeft = daysLeft)
                }
            }
            val cats = current?.byCategory ?: emptyList()
            if (cats.isNotEmpty()) {
                item(key = "cats") { CategoryCard(cats = cats, total = spent) }
            }
            item(key = "title") {
                Text(
                    "Transactions",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Ink,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
            if (current == null) {
                item(key = "loading") { Text("Reading your messages…", color = Muted) }
            } else if (current.txns.isEmpty()) {
                item(key = "empty") {
                    Text(
                        "No payment messages found for this month. " +
                            "Tap + to add a cash expense yourself.",
                        color = Muted
                    )
                }
            } else {
                items(current.txns, key = { it.id }) { txn ->
                    TxnRow(txn = txn, onClick = { selected = txn })
                }
            }
        }

        FloatingActionButton(
            onClick = { showAdd = true },
            containerColor = Green,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) {
            Text("+", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }

    if (showBudget) {
        BudgetDialog(
            initial = budget,
            onDismiss = { showBudget = false },
            onSave = { value ->
                store.budget = value
                budget = value
                showBudget = false
            }
        )
    }
    if (showAdd) {
        AddExpenseDialog(
            onDismiss = { showAdd = false },
            onSave = { amount, note, category ->
                store.addManual(amount, note, category, System.currentTimeMillis())
                showAdd = false
                month = YearMonth.now()
                version = version + 1
            }
        )
    }
    val sel = selected
    if (sel != null) {
        TxnDialog(
            txn = sel,
            onDismiss = { selected = null },
            onCategory = { cat ->
                if (!sel.manual) store.setCategory(sel.id, cat)
                selected = null
                version = version + 1
            },
            onToggleExcluded = {
                if (sel.manual) store.deleteManual(sel.id)
                else store.setExcluded(sel.id, !sel.excluded)
                selected = null
                version = version + 1
            }
        )
    }
}

@Composable
private fun Card(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBg)
            .padding(18.dp)
    ) {
        content()
    }
}

@Composable
private fun MonthHeader(
    month: YearMonth,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "‹",
            fontSize = 32.sp,
            color = Green,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { onBack() }
                .padding(horizontal = 16.dp, vertical = 2.dp)
        )
        Text(
            month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Ink,
            textAlign = TextAlign.Center,
            modifier = Modifier.weight(1f)
        )
        Text(
            "›",
            fontSize = 32.sp,
            color = if (canGoForward) Green else Track,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable(enabled = canGoForward) { onForward() }
                .padding(horizontal = 16.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun Bar(fraction: Float, color: Color) {
    val f = if (fraction.isNaN()) 0f else fraction.coerceIn(0f, 1f)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(RoundedCornerShape(5.dp))
            .background(Track)
    ) {
        if (f > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(color)
            )
        }
    }
}

@Composable
private fun BudgetCard(
    budget: Double,
    spent: Double,
    left: Double,
    daysLeft: Int,
    balance: Double?,
    received: Double,
    onEdit: () -> Unit
) {
    Card {
        if (budget <= 0.0) {
            Text("Spent this month", color = Muted, fontSize = 14.sp)
            Text(money(spent), fontSize = 38.sp, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onEdit) { Text("Set a monthly budget") }
        } else {
            val used = (spent / budget).toFloat()
            val color = if (left < 0) Red else if (used > 0.8f) Amber else Green
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (left < 0) "Over budget by" else "Left to spend",
                    color = Muted,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "Edit budget",
                    color = Green,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onEdit() }
                        .padding(6.dp)
                )
            }
            Text(
                money(Math.abs(left)),
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Spacer(Modifier.height(10.dp))
            Bar(fraction = used, color = color)
            Spacer(Modifier.height(8.dp))
            Text(
                "Spent " + money(spent) + " of " + money(budget),
                color = Ink,
                fontSize = 14.sp
            )
            if (daysLeft > 0 && left > 0) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "About " + money(left / daysLeft) + " a day for the next " +
                        daysLeft + (if (daysLeft == 1) " day" else " days"),
                    color = Muted,
                    fontSize = 14.sp
                )
            }
        }
        if (balance != null || received > 0.0) {
            Spacer(Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Track)
            )
            Spacer(Modifier.height(10.dp))
            if (balance != null) {
                Text(
                    "Bank balance in latest SMS: " + money(balance),
                    color = Muted,
                    fontSize = 13.sp
                )
            }
            if (received > 0.0) {
                Text(
                    "Money received this month: " + money(received),
                    color = Muted,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun AffordCard(budget: Double, left: Double, daysLeft: Int) {
    var input by remember { mutableStateOf("") }
    Card {
        Text("Can I buy this?", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Price in ₹") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        val price = parseAmount(input)
        if (price != null && price > 0.0) {
            Spacer(Modifier.height(10.dp))
            if (budget <= 0.0) {
                Text("Set a monthly budget first, then I can answer.", color = Muted)
            } else {
                val after = left - price
                val verdict: String
                val detail: String
                val color: Color
                if (after < 0) {
                    color = Red
                    verdict = "Not within budget"
                    detail = if (left <= 0)
                        "You are already over this month's budget."
                    else
                        "It costs " + money(price - left) + " more than the " +
                            money(left) + " you have left."
                } else {
                    val share = if (left > 0) price / left else 1.0
                    val perDay = if (daysLeft > 0) after / daysLeft else after
                    if (share > 0.5) {
                        color = Amber
                        verdict = "Possible, but it's a big bite"
                    } else {
                        color = Green
                        verdict = "Yes, it fits"
                    }
                    detail = "You'd have " + money(after) + " left, about " + money(perDay) +
                        " a day for " + daysLeft + (if (daysLeft == 1) " day." else " days.")
                }
                Text(verdict, color = color, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(detail, color = Ink, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun CategoryCard(cats: List<Pair<String, Double>>, total: Double) {
    Card {
        Text("Where it went", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
        Spacer(Modifier.height(10.dp))
        for (entry in cats) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(entry.first, color = Ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(money(entry.second), color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.height(4.dp))
            Bar(fraction = if (total > 0) (entry.second / total).toFloat() else 0f, color = Green)
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun TxnRow(txn: Txn, onClick: () -> Unit) {
    val time = remember(txn.time) {
        SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH).format(Date(txn.time))
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CardBg)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                txn.merchant,
                color = if (txn.excluded) Muted else Ink,
                fontWeight = FontWeight.Medium,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val sub = when {
                txn.excluded -> "Not counted"
                !txn.isDebit -> "Received"
                txn.manual -> txn.category + " · added by you"
                else -> txn.category
            }
            Text(time + " · " + sub, color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(10.dp))
        Text(
            (if (txn.isDebit) "" else "+") + money(txn.amount),
            color = if (txn.excluded) Muted else if (txn.isDebit) Ink else Green,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) Color.White else Ink,
        fontSize = 14.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Green else GreenSoft)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun CategoryChips(selected: String, onSelect: (String) -> Unit) {
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (cat in SmsParser.CATEGORIES) {
            Chip(label = cat, selected = cat == selected, onClick = { onSelect(cat) })
        }
    }
}

@Composable
private fun BudgetDialog(initial: Double, onDismiss: () -> Unit, onSave: (Double) -> Unit) {
    var input by remember {
        mutableStateOf(if (initial > 0) initial.toLong().toString() else "")
    }
    val value = parseAmount(input)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Monthly budget") },
        text = {
            Column {
                Text("How much do you want to spend in a month?", color = Muted, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("Amount in ₹") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (value != null) onSave(value) },
                enabled = value != null && value >= 0.0
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun AddExpenseDialog(
    onDismiss: () -> Unit,
    onSave: (Double, String, String) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Cash") }
    val value = parseAmount(amount)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add an expense") },
        text = {
            Column {
                Text(
                    "For cash or anything that didn't send an SMS.",
                    color = Muted,
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Amount in ₹") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("What was it for?") },
                    singleLine = true
                )
                Spacer(Modifier.height(12.dp))
                CategoryChips(selected = category, onSelect = { category = it })
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (value != null) onSave(value, note.trim(), category) },
                enabled = value != null && value > 0.0
            ) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun TxnDialog(
    txn: Txn,
    onDismiss: () -> Unit,
    onCategory: (String) -> Unit,
    onToggleExcluded: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(txn.merchant, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    (if (txn.isDebit) "" else "+") + money(txn.amount),
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (txn.isDebit) Ink else Green
                )
                Text(
                    SimpleDateFormat("EEE d MMM yyyy, h:mm a", Locale.ENGLISH)
                        .format(Date(txn.time)),
                    color = Muted,
                    fontSize = 13.sp
                )
                if (txn.isDebit && !txn.manual) {
                    Spacer(Modifier.height(14.dp))
                    Text("Category", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    CategoryChips(selected = txn.category, onSelect = onCategory)
                }
                if (txn.body.isNotBlank()) {
                    Spacer(Modifier.height(14.dp))
                    Text("Message", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(txn.body, color = Ink, fontSize = 13.sp)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = {
            TextButton(onClick = onToggleExcluded) {
                Text(
                    when {
                        txn.manual -> "Delete"
                        txn.excluded -> "Count it again"
                        else -> "Don't count this"
                    },
                    color = if (txn.manual || !txn.excluded) Red else Green
                )
            }
        }
    )
}
