package com.spendtrack.app

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeFormatterBuilder
import java.util.Locale

/** Kind of line in a Google Pay transaction statement. */
enum class GpayKind { PAYMENT, RECEIVED, TOPUP }

/** One entry of a Google Pay statement. */
data class GpayTxn(
    val id: String,
    val time: Long,
    val amount: Double,
    val kind: GpayKind,
    val name: String,
    /** True when it was paid from the UPI Lite balance (no bank SMS for these). */
    val viaLite: Boolean,
    val ref: String?,
    val category: String
) {
    val isDebit: Boolean get() = kind != GpayKind.RECEIVED
}

data class GpayStatement(
    /** First and last day the statement covers. */
    val from: LocalDate,
    val to: LocalDate,
    val txns: List<GpayTxn>
)

/**
 * Reads the text of a Google Pay "Transaction statement" PDF. Pure Kotlin so it
 * can be tested off the phone; the PDF-to-text step happens in Data.kt.
 */
object GpayParser {

    private val I = RegexOption.IGNORE_CASE

    private val entryDate = Regex("\\b([0-3]?[0-9]) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec), ([0-9]{4})\\b")
    private val period = Regex(
        "([0-3]?[0-9]) ([A-Za-z]+) ([0-9]{4})\\s*[-–]\\s*([0-3]?[0-9]) ([A-Za-z]+) ([0-9]{4})"
    )
    private val clock = Regex("\\b([01]?[0-9]):([0-5][0-9]) ?(AM|PM)\\b", I)
    private val amount = Regex("₹\\s?([0-9][0-9,]*(?:\\.[0-9]{1,2})?)")
    private val txnId = Regex("UPI Transaction ID:?\\s*([0-9]{6,20})", I)
    private val stop = "(?=\\s+₹|\\s+[01]?[0-9]:[0-5][0-9] ?(?:AM|PM)\\b|\\s+UPI Transaction|\\s+Paid by|\\s*$)"
    private val paidTo = Regex("Paid to (.+?)$stop", I)
    private val receivedFrom = Regex("Received from (.+?)$stop", I)
    private val topUp = Regex("Top-?\\s?up to UPI Lite", I)
    private val selfTransfer = Regex("\\bSelf transfer", I)
    private val liteMethod = Regex("Paid by UPI Lite", I)

    private val shortDate: DateTimeFormatter = DateTimeFormatterBuilder()
        .parseCaseInsensitive().appendPattern("d MMM uuuu").toFormatter(Locale.ENGLISH)
    private val longDate: DateTimeFormatter = DateTimeFormatterBuilder()
        .parseCaseInsensitive().appendPattern("d MMMM uuuu").toFormatter(Locale.ENGLISH)

    fun looksLikeGpay(text: String): Boolean =
        text.contains("UPI Transaction ID", ignoreCase = true) &&
            (text.contains("Google Pay", ignoreCase = true) || text.contains("Transaction statement", ignoreCase = true))

    fun parse(text: String, zone: ZoneId = ZoneId.systemDefault()): GpayStatement {
        val clean = text.replace(' ', ' ').replace(Regex("[ \\t]+"), " ")

        // Cut the text into entries: each one starts at a date like "01 Oct, 2026".
        val starts = entryDate.findAll(clean).toList()
        val txns = ArrayList<GpayTxn>()
        val seen = HashMap<String, Int>()
        for ((n, m) in starts.withIndex()) {
            val end = if (n + 1 < starts.size) starts[n + 1].range.first else clean.length
            // Page notes and footers sit between entries; keep them out of this one.
            var body = clean.substring(m.range.last + 1, end)
            val note = body.indexOf("Note: This statement", ignoreCase = true)
            if (note >= 0) body = body.substring(0, note)
            val flat = body.replace(Regex("\\s+"), " ").trim()

            val day = try {
                LocalDate.parse(m.groupValues[1] + " " + m.groupValues[2] + " " + m.groupValues[3], shortDate)
            } catch (e: Exception) {
                continue
            }
            val money = amount.find(flat)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: continue
            if (money <= 0.0) continue

            val kind: GpayKind
            val name: String
            when {
                topUp.containsMatchIn(flat) -> {
                    kind = GpayKind.TOPUP
                    name = "UPI Lite top-up"
                }
                selfTransfer.containsMatchIn(flat) -> continue
                paidTo.containsMatchIn(flat) -> {
                    kind = GpayKind.PAYMENT
                    name = tidy(paidTo.find(flat)!!.groupValues[1])
                }
                receivedFrom.containsMatchIn(flat) -> {
                    kind = GpayKind.RECEIVED
                    name = tidy(receivedFrom.find(flat)!!.groupValues[1])
                }
                else -> continue
            }

            val c = clock.find(flat)
            val at = if (c != null) {
                var h = c.groupValues[1].toInt() % 12
                if (c.groupValues[3].equals("PM", ignoreCase = true)) h += 12
                LocalDateTime.of(day.year, day.month, day.dayOfMonth, h, c.groupValues[2].toInt())
            } else day.atTime(12, 0)

            val ref = txnId.find(flat)?.groupValues?.get(1)
            val lite = kind != GpayKind.TOPUP && liteMethod.containsMatchIn(flat)
            val category = when (kind) {
                GpayKind.PAYMENT -> SmsParser.guessCategory(name, name)
                GpayKind.TOPUP -> "UPI Lite"
                GpayKind.RECEIVED -> "Other"
            }
            val base = "g" + (ref ?: Integer.toHexString((at.toString() + "|" + name + "|" + money).hashCode()))
            val k = (seen[base] ?: 0) + 1
            seen[base] = k
            txns.add(
                GpayTxn(
                    id = if (k == 1) base else "$base#$k",
                    time = at.atZone(zone).toInstant().toEpochMilli(),
                    amount = money,
                    kind = kind,
                    name = name,
                    viaLite = lite,
                    ref = ref,
                    category = category
                )
            )
        }
        if (txns.isEmpty()) throw StatementException("No Google Pay transactions were found in this PDF.")

        val zoneDays = txns.map { java.time.Instant.ofEpochMilli(it.time).atZone(zone).toLocalDate() }
        var from = zoneDays.minOrNull()!!
        var to = zoneDays.maxOrNull()!!
        val p = period.find(clean)
        if (p != null) {
            try {
                val a = LocalDate.parse(p.groupValues[1] + " " + p.groupValues[2] + " " + p.groupValues[3], longDate)
                val b = LocalDate.parse(p.groupValues[4] + " " + p.groupValues[5] + " " + p.groupValues[6], longDate)
                if (!b.isBefore(a)) {
                    from = a
                    to = b
                }
            } catch (e: Exception) {
                // keep the range of the entries themselves
            }
        }
        return GpayStatement(from, to, txns)
    }

    private fun tidy(raw: String): String {
        var s = raw.trim().trim('.', ',', ';', ':', '-', '|', ' ')
        if (s.length > 30) s = s.substring(0, 30).trim()
        return if (s.length < 2) "Google Pay payment" else s
    }
}

/** Outcome of comparing Google Pay entries with what the app already knows. */
class GpayMatch(
    /** Google Pay payments nothing else covers: these get added to the list. */
    val newLines: List<GpayTxn>,
    /** Position in the known list -> the Google Pay entry that matched it. */
    val matched: Map<Int, GpayTxn>
)

/**
 * Finds which Google Pay payments are already known from SMS or a bank
 * statement, so nothing is counted twice. Top-ups are left out here; they are
 * handled as transfers. The UPI Transaction ID is the same number banks print
 * as the UPI reference, so that is tried first. Payments made from the bank
 * account can also match on the same amount within a day and a half; UPI Lite
 * payments never reach the bank one by one, so they only match on the ID.
 */
fun matchGpay(gpay: List<GpayTxn>, known: List<SmsKey>): GpayMatch {
    val used = BooleanArray(known.size)
    val matched = HashMap<Int, GpayTxn>()
    val covered = HashSet<String>()
    // Known lines that are really UPI Lite top-ups must not be mistaken for a
    // payment of the same amount.
    val topupRefs = gpay.filter { it.kind == GpayKind.TOPUP }.mapNotNull { it.ref }.toSet()
    for (i in known.indices) if (known[i].ref != null && known[i].ref in topupRefs) used[i] = true
    val payments = gpay.filter { it.kind != GpayKind.TOPUP }
    for (g in payments) {
        val ref = g.ref ?: continue
        val i = known.indices.firstOrNull { !used[it] && known[it].ref == ref && known[it].isDebit == g.isDebit }
        if (i != null) {
            used[i] = true
            matched[i] = g
            covered.add(g.id)
        }
    }
    val window = 36L * 60 * 60 * 1000
    for (g in payments) {
        if (g.id in covered || g.viaLite) continue
        var best = -1
        var bestGap = Long.MAX_VALUE
        for (i in known.indices) {
            if (used[i] || known[i].isDebit != g.isDebit) continue
            if (Math.abs(known[i].amount - g.amount) >= 0.005) continue
            val gap = Math.abs(known[i].time - g.time)
            if (gap <= window && gap < bestGap) {
                best = i
                bestGap = gap
            }
        }
        if (best >= 0) {
            used[best] = true
            matched[best] = g
            covered.add(g.id)
        }
    }
    return GpayMatch(payments.filter { it.id !in covered }, matched)
}
